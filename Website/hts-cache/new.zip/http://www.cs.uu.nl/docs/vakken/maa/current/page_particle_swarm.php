<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_particle_swarm.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Particle swarm optimisation</H1>
<P><!-- description -->
Particle swarm optimisation (commonly abbreviated as PSO) is an optimisation technique inspired by the idea of bee swarms searching for nectar.  PSO can be seen as multi-agent hill-climbing, where agents communicate their position and adapt their orientation on the basis of a mix of their own position and the positions of others.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Particle swarm optimization; an overview&rdquo; <I>Poli et al.</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=particle+swarm+optimization+an+overview+poli+et+al+2007" target="_blank">scholar</A>, <A href="lib.php?query=particle+swarm+optimization+an+overview+poli+et+al+2007" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>Wiki's page on <A href="https://en.wikipedia.org/wiki/Particle_swarm_optimization" target="_blank">PSO</A>.</LI>
<LI>&ldquo;Particle swarm optimization (Enc. of Machine Learning)&rdquo; <I>J. Kennedy et al.</I> (2011) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=particle+swarm+optimization+enc+of+machine+learning+j+kennedy+et+al+2011" target="_blank">scholar</A>, <A href="lib.php?query=particle+swarm+optimization+enc+of+machine+learning+j+kennedy+et+al+2011" target="_blank">lib</A>]</LI>
<LI>&ldquo;Particle swarm optimization&rdquo; <I>Venter et al. (AIAA journal)</I> (2003) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=particle+swarm+optimization+venter+et+al+aiaa+journal+2003" target="_blank">scholar</A>, <A href="lib.php?query=particle+swarm+optimization+venter+et+al+aiaa+journal+2003" target="_blank">lib</A>]</LI>
<LI>&ldquo;Particle swarm optimization; developments, applications and resources&rdquo; <I>Eberhart et al.</I> (2001) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=particle+swarm+optimization+developments+applications+and+resources+eberhart+et+al+2001" target="_blank">scholar</A>, <A href="lib.php?query=particle+swarm+optimization+developments+applications+and+resources+eberhart+et+al+2001" target="_blank">lib</A>]</LI>
<LI>&ldquo;Empirical study of particle swarm optimization&rdquo; <I>Eberhart et al.</I> (1999) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=empirical+study+of+particle+swarm+optimization+eberhart+et+al+1999" target="_blank">scholar</A>, <A href="lib.php?query=empirical+study+of+particle+swarm+optimization+eberhart+et+al+1999" target="_blank">lib</A>]</LI>

<!--
Empirical study of particle swarm optimization - Eberhart et al. - 1999.pdf
Particle swarm optimization (Enc. of Machine Learning) - J. Kennedy et al. - 2011.pdf
Particle swarm optimization - Venter et al. (AIAA journal) - 2003.pdf
Particle swarm optimization; an overview - Poli et al. - 2017.pdf
Particle swarm optimization; developments, applications and resources - Eberhart et al. - 2001.pdf
-->


</OL>
</P>

<H5>Demo</H5>
<P>
<UL>
<LI>
Netlogo offers a simple PSO demo in its sample library which is included in Netlogo's installation.
</LI>
</UL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Fri, 15 Apr 2016 18:03:30 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_particle_swarm.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
