<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_extensive_form.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Learning games in extensive form</H1>


<P><!-- description -->
Games in extensive form are games were moves are executed in succession.  Examples of such games are tic-tac-toe, chess, and backgammon, but also abstract economical games, such as the pricing of goods.  The theory of learning in extensive form games differs from the theory of learning in normal form games but can be studied in the same abstract manner.
</P>
<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Learning to play games in extensive form by valuation&rdquo; <I>Jehiel &amp; Samet</I> (2005) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+to+play+games+in+extensive+form+by+valuation+jehiel+samet+2005" target="_blank">scholar</A>, <A href="lib.php?query=learning+to+play+games+in+extensive+form+by+valuation+jehiel+samet+2005" target="_blank">lib</A>]</LI>
</UL>
</P>


<H5>Support</H5><!-- Support -->
<P>
<UL>
<LI>&ldquo;Learning in extensive form games, I. Self-confirming equilibria&rdquo; <I>Fudenberg &amp; Kreps</I> (1995) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+in+extensive+form+games+i+self+confirming+equilibria+fudenberg+kreps+1995" target="_blank">scholar</A>, <A href="lib.php?query=learning+in+extensive+form+games+i+self+confirming+equilibria+fudenberg+kreps+1995" target="_blank">lib</A>]</LI>
<LI>&ldquo;Learning in extensive form games, II.  Experimentation and Nash equilibrium&rdquo; <I>Fudenberg</I> (1996) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+in+extensive+form+games+ii+experimentation+and+nash+equilibrium+fudenberg+1996" target="_blank">scholar</A>, <A href="lib.php?query=learning+in+extensive+form+games+ii+experimentation+and+nash+equilibrium+fudenberg+1996" target="_blank">lib</A>]</LI>
<LI>&ldquo;Multi-agent learning in extensive games with complete information&rdquo; <I>Huang &amp; Sycara</I> (2003) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=multi+agent+learning+in+extensive+games+with+complete+information+huang+sycara+2003" target="_blank">scholar</A>, <A href="lib.php?query=multi+agent+learning+in+extensive+games+with+complete+information+huang+sycara+2003" target="_blank">lib</A>]</LI>
<LI>&ldquo;A reinforcement learning process in extensive form games&rdquo; <I>Laslier &amp; Walliser</I> (2005) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=a+reinforcement+learning+process+in+extensive+form+games+laslier+walliser+2005" target="_blank">scholar</A>, <A href="lib.php?query=a+reinforcement+learning+process+in+extensive+form+games+laslier+walliser+2005" target="_blank">lib</A>]</LI>
<LI>&ldquo;Reinforcement learning in extensive form games with incomplete information.  The bargaining case study&rdquo; <I>Lazaric et al.</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=reinforcement+learning+in+extensive+form+games+with+incomplete+information+the+bargaining+case+study+lazaric+et+al+2007" target="_blank">scholar</A>, <A href="lib.php?query=reinforcement+learning+in+extensive+form+games+with+incomplete+information+the+bargaining+case+study+lazaric+et+al+2007" target="_blank">lib</A>]</LI>
</UL>
</P>




<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 02 Apr 2014 16:58:19 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_extensive_form.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
