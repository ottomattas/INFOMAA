<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_cournot_dynamics.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Cournot Dynamics</H1>

<P><!-- description -->
We consider adaptation in repeated two-player games with real-valued actions.  An example of a real-valued action is the production of lemonade in hectoliters a day.  Players adapt to each other's production.  For some profit functions, and some modes of adaptation, a chaotic (that is, a predictable but wildly varying) dynamics will occur.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_CournotDynamics.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Dec  9, 2013.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Chaos in Duopoly Pricing&rdquo; <I>Puu</I> (1991) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=chaos+in+duopoly+pricing+puu+1991" target="_blank">scholar</A>, <A href="lib.php?query=chaos+in+duopoly+pricing+puu+1991" target="_blank">lib</A>]*</LI>
<LI>&ldquo;The Chaotic Duopolists Revisited&rdquo; <I>Puu</I> (1996) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+chaotic+duopolists+revisited+puu+1996" target="_blank">scholar</A>, <A href="lib.php?query=the+chaotic+duopolists+revisited+puu+1996" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Speltheorie voor Economen&rdquo; <I>H. Peters</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=speltheorie+voor+economen+h+peters+2007" target="_blank">scholar</A>, <A href="lib.php?query=speltheorie+voor+economen+h+peters+2007" target="_blank">lib</A>]</LI>
<LI>&ldquo;Exotic Phenomena in Games and Duopoly&rdquo; <I>Rand</I> (1978) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=exotic+phenomena+in+games+and+duopoly+rand+1978" target="_blank">scholar</A>, <A href="lib.php?query=exotic+phenomena+in+games+and+duopoly+rand+1978" target="_blank">lib</A>]</LI>
<LI>&ldquo;Complex Dynamics with Three Oligopolists&rdquo; <I>Puu</I> (1996) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=complex+dynamics+with+three+oligopolists+puu+1996" target="_blank">scholar</A>, <A href="lib.php?query=complex+dynamics+with+three+oligopolists+puu+1996" target="_blank">lib</A>]</LI>
<LI>&ldquo;Simple and complex adjustment dynamics in Cournot duopoly models&rdquo; <I>Kopel</I> (1996) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=simple+and+complex+adjustment+dynamics+in+cournot+duopoly+models+kopel+1996" target="_blank">scholar</A>, <A href="lib.php?query=simple+and+complex+adjustment+dynamics+in+cournot+duopoly+models+kopel+1996" target="_blank">lib</A>]</LI>
<LI>&ldquo;Multistability and cyclic attractors in duopoly games&rdquo; <I>Bisschi</I> (1998) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=multistability+and+cyclic+attractors+in+duopoly+games+bisschi+1998" target="_blank">scholar</A>, <A href="lib.php?query=multistability+and+cyclic+attractors+in+duopoly+games+bisschi+1998" target="_blank">lib</A>]</LI>
<LI>&ldquo;Explicit Stability Zones for Cournot Game with 3-4 Competitors&rdquo; <I>Agiza</I> (1998) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=explicit+stability+zones+for+cournot+game+with+3+4+competitors+agiza+1998" target="_blank">scholar</A>, <A href="lib.php?query=explicit+stability+zones+for+cournot+game+with+3+4+competitors+agiza+1998" target="_blank">lib</A>]</LI>
<LI>&ldquo;On the Analysis of Stability Bifurcation Chaos and&rdquo; <I>Agiza</I> (1999) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=on+the+analysis+of+stability+bifurcation+chaos+and+agiza+1999" target="_blank">scholar</A>, <A href="lib.php?query=on+the+analysis+of+stability+bifurcation+chaos+and+agiza+1999" target="_blank">lib</A>]</LI>
<LI>&ldquo;Dynamics of a Cournot Game with N Competitors&rdquo; <I>Agiza</I> (1998) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=dynamics+of+a+cournot+game+with+n+competitors+agiza+1998" target="_blank">scholar</A>, <A href="lib.php?query=dynamics+of+a+cournot+game+with+n+competitors+agiza+1998" target="_blank">lib</A>]</LI>
</OL>
</P>

<H5>Demos</H5>
<P>
<UL>
<LI><A href="netlogo_cournot_dynamics.php" target="_blank">Netlogo demo</A> of Cournot dynamics.</LI>
</UL>
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Sun, 27 Apr 2014 21:32:14 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_cournot_dynamics.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
