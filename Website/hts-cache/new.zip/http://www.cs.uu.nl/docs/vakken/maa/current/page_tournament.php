<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_tournament.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Comparing MAL algorithms empirically</H1>


<P><!-- description -->
Until 2005, say, MAL research was typically done this way: (1) invent a nifty MAL algorithm (2) compare the nifty algorithm with a handful of trendy MAL algorithms, based on a few popular 2x2 games (typically prisoner's dilemma, chicken, battle of the sexes).  Then show that the new algorithm performs much better.  Later, MAL algorithms were compared more systematically, either by pitting games against each other in tournaments on interesting games (Zawadzki <I>et al.</I>) or else through evolutionary dynamics (Airiau <I>et al.</I>), or else in knockock-out tournaments with randomly generated 3x3 games (Bouzy <I>et al.</I>).  Remarkably all studies yield different best MAL algorithms.
</P>
<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_Tournament.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Jun 21, 2020.
      </TD>
      <TD>
<H2>Screencast</H2> <A href="https://www.youtube.com/playlist?list=PL8AyDiByAbIR0hCbEw0o4Rtaqx1XJIpFF" target="_blank">Youtube</A>
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Empirically evaluating multiagent learning algorithms&rdquo; <I>Zawadzki, Lipson &amp; Leyton-Brown</I> (2014) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=empirically+evaluating+multiagent+learning+algorithms+zawadzki+lipson+leyton+brown+2014" target="_blank">scholar</A>, <A href="lib.php?query=empirically+evaluating+multiagent+learning+algorithms+zawadzki+lipson+leyton+brown+2014" target="_blank">lib</A>]</lI>
</UL>
</P>


<H5>Support</H5><!-- Support -->
<P>
<UL>
<LI>&ldquo;Dynamics of strategy distribution in iterated games&rdquo; <I>Airiau et al.</I> (2004) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=dynamics+of+strategy+distribution+in+iterated+games+airiau+et+al+2004" target="_blank">scholar</A>, <A href="lib.php?query=dynamics+of+strategy+distribution+in+iterated+games+airiau+et+al+2004" target="_blank">lib</A>]</LI>
<LI>&ldquo;Evolutionary Tournament-Based Comparison of Learning and Non-Learning Strategies for Iterated Games&rdquo; <I>Airiau et al.</I> (2005) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=evolutionary+tournament+based+comparison+of+learning+and+non+learning+strategies+for+iterated+games+airiau+et+al+2005" target="_blank">scholar</A>, <A href="lib.php?query=evolutionary+tournament+based+comparison+of+learning+and+non+learning+strategies+for+iterated+games+airiau+et+al+2005" target="_blank">lib</A>]</LI>
<LI>&ldquo;Evolutionary Tournament-Based Comparison of Learning and Non-Learning Strategies for Iterated Games&rdquo; <I>Airiau et al.</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=evolutionary+tournament+based+comparison+of+learning+and+non+learning+strategies+for+iterated+games+airiau+et+al+2007" target="_blank">scholar</A>, <A href="lib.php?query=evolutionary+tournament+based+comparison+of+learning+and+non+learning+strategies+for+iterated+games+airiau+et+al+2007" target="_blank">lib</A>] (Elaboration of previous paper.)</LI>
<LI>&ldquo;Multi-agent learning experiments on repeated matrix games&rdquo; <I>Bouzy et al.</I> (2010) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=multi+agent+learning+experiments+on+repeated+matrix+games+bouzy+et+al+2010" target="_blank">scholar</A>, <A href="lib.php?query=multi+agent+learning+experiments+on+repeated+matrix+games+bouzy+et+al+2010" target="_blank">lib</A>]</LI>
<LI>&ldquo;Hedging Algorithms and Repeated Matrix Games&rdquo; <I>Bouzy et al.</I> (2011) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=hedging+algorithms+and+repeated+matrix+games+bouzy+et+al+2011" target="_blank">scholar</A>, <A href="lib.php?query=hedging+algorithms+and+repeated+matrix+games+bouzy+et+al+2011" target="_blank">lib</A>]</LI>
</UL>




<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Mon, 29 Jan 2018 22:29:49 +01001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_tournament.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
