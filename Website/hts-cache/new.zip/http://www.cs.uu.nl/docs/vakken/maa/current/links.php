<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/links.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Relevant links</H1>

<H2>Useful documents</H2>
<P>
<UL>
<LI><A href="some_books.php" target="main">Covers of books</A> that I took with me during the first meeting.</LI>
<LI><A href="diagram.php" target="main">Interdependencies</A> between topics in multi-agent learning.</LI>
<LI><A href="abbreviations.php" target="main">Abbreviations in probability</A>.</LI>
</UL>
</P>

<H2>Related courses</H2>
<P>
<UL>

<LI><A href="http://www.cs.uu.nl/docs/vakken/ias/" target="_blank">(CK1W0008) Inleiding adaptieve systemen</A> (first-y ear CKI bachelor course on adaptive systems in Dutch), Gerard Vreeswijk.
</LI>

<LI>
<A href="http://www.cs.caltech.edu/~adamw/courses/241/" target="_blank">(CS/SS 241a) Introduction to SISL:
Topics in Algorithmic game theory</A>
Adam Wierman,
John Ledyard,
Jason Marden.
</LI>

<LI>
<A href="http://www.cs.brown.edu/courses/cs244/" target="_blank">(CS 244) Game-Theoretic Artificial Intelligence</A>, Amy Greenwald.
</LI>

<LI>
<A href="http://ecee.colorado.edu/marden/5018.html" target="_blank">(ECEN 4018/5018) Game Theory and Multiagent Systems </A>, Jason Marden.
</LI>

<LI>
<A href="http://como.vub.ac.be/teaching:mals" target="_top">Multi-agent Learning (Learning Dynamics)</A>.
Ann Now&eacute;, Tom Lenaerts.
Computational Modeling Lab,
Vrije Universiteit Brussel.
</LI>

<LI>
<A href="http://users.ecs.soton.ac.uk/jemc/spring07.html" target="_blank">(CS-500) Multiagent Reinforcement Learning</A>.
Rutgers University,
Spring 2007,
Michael L. Littman, Enrique Munoz de Cote.
</LI>

<LI>
<A href="http://www.cs.uu.nl/docs/vakken/maa/2008-09/" target="_blank">(INFOMAA-2009) Previous edition of this course</A>, in 2008-09 given by
Frank Dignum, Loris Penserini, and Hado van Hasselt.
</LI>

</UL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Thu, 30 Apr 2020 15:42:16 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/links.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>

