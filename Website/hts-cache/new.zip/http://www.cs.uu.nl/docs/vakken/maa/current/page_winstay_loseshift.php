<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_winstay_loseshift.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Win-stay lose-shift</H1>

<P><!-- description -->
Meet Pavlov. This strategy is as simple as tit-for-tat and embodies the fundamental behavioural mechanism win-stay, lose-shift, which seems to be a widespread rule. Pavlov's success is based on two important advantages over tit-for-tat: it can correct occasional mistakes and exploit unconditional cooperators. This second feature prevents Pavlov populations from being undermined by unconditional cooperators, which in turn invite defectors. Pavlov seems to be more robust than tit-for-tat, suggesting that cooperative behaviour in natural situations may often be based on win-stay, lose-shift.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P><!--<P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
<H2>Slides</H2> T.B.P.      </TD>
      <TD align="right">
<H2>Assignment</H2> T.B.P.      </TD>
   </TR>
</TABLE>
</P>-->

<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Tit-for-tat or Win-stay, Lose-shift&rdquo; <I>Imhof</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=tit+for+tat+or+win+stay+lose+shift+imhof+2007" target="_blank">scholar</A>, <A href="lib.php?query=tit+for+tat+or+win+stay+lose+shift+imhof+2007" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<UL>
<LI>&ldquo;A strategy of win-stay, lose-shift that outperforms tit-for-tat in the Prisoner's Dilemma game&rdquo; <I>Nowak et al.</I> Nature. (1993) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=a+strategy+of+win+stay+lose+shift+that+outperforms+tit+for+tat+in+the+prisoner%27s+dilemma+game+nowak+et+al+nature+1993" target="_blank">scholar</A>, <A href="lib.php?query=a+strategy+of+win+stay+lose+shift+that+outperforms+tit+for+tat+in+the+prisoner's+dilemma+game+nowak+et+al+nature+1993&nr=1" target="_blank">lib</A>]; &ldquo;Evolutionary games and spatial chaos&rdquo; <I>M.A. Nowak &amp; R.M. May</I> (1992) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=evolutionary+games+and+spatial+chaos+m+a+nowak+r+m+may+1992" target="_blank">scholar</A>, <A href="lib.php?query=evolutionary+games+and+spatial+chaos+m+a+nowak+r+m+may+1992&nr=2" target="_blank">lib</A>].  <FONT color="red">Warning: 2 matches for '<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=nowak" target="_blank">nowak</A>'.</FONT></LI>
<LI>&ldquo;Win-stay Lose-shift.  An Elementary Learning Rule for Normal Form Games&rdquo; <I>Posch</I> (1997) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=win+stay+lose+shift+an+elementary+learning+rule+for+normal+form+games+posch+1997" target="_blank">scholar</A>, <A href="lib.php?query=win+stay+lose+shift+an+elementary+learning+rule+for+normal+form+games+posch+1997" target="_blank">lib</A>]</LI>
<LI>&ldquo;Competition and Cooperation&rdquo; <I>Flake</I> (1998). Ch. 17 of The Computational Beauty of Nature [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=competition+and+cooperation+flake+1998+ch+17+of+the+computational+beauty+of+nature" target="_blank">scholar</A>, <A href="lib.php?query=competition+and+cooperation+flake+1998+ch+17+of+the+computational+beauty+of+nature" target="_blank">lib</A>].    Sec. 17.5:
&ldquo;Ecological and Spatial Worlds,&rdquo; pp. 297-301.</LI>
</UL>
</P>

<H5>Demos</H5>
<P>
<UL>
<LI><A href="netlogo_tournament_evolutionary.php" target="_blank">Netlogo demo</A> of an evolutionary game.</LI>
</UL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Tue, 10 Feb 2015 22:52:53 +01001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_winstay_loseshift.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
