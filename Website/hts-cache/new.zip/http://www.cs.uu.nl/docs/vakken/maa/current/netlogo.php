<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/netlogo.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Netlogo demos</H1>

<P>There are some alternatives.   Each alternative has its pros and cons.</P>

<P>
<OL>
<LI><A href="netlogo-4.php" target="main">Page with original Netlogo 4 demos</A>.  This is the prime source.  For a long time, these demos were runnable in the browser as Java applets, which  was a great way to present demos, as the applet's GUI's were identical to Netlogo's GUI's, and they ran as fast as the original Netlogo apps.  In the course of time, however, browsers became very restrictive with applets, which made the applets basically useless.  You can still invoke the applets if you dictate the browser to be very permissive with security on applets. Another way to get the Netlogo 4 demos running is to download Netlogo 4, download the demo of your interest, load the demo in Netlogo 4, and run it.</LI>
<LI><A href="netlogo-web.php" target="main">Page with links to Netlogo 6 files that can be run directly through the "netlogo-web" server</A>.  This probably the easiest way to get going.  However, the interfaces are not that pretty, and some of my Netlogo apps use external libraries (called <I>extensions</I> in Netlogo) which Netlogo web doesn't run and then you're stuck.</LI>
<LI>In 2019 the then existing <A href="netlogo-4.php" target="main">Netlogo&nbsp;4&nbsp;demos</A> were <A href="stuff/Demos_Netlogo_v6.0.4.zip" target="_blank">translated to Netlogo version 6 and zipped</A> by Yolan van der Horst.   This zip was last updated Thu, 30 Apr 2020 15:38:53 +0200.  Sometimes a Netlogo program needs extra libraries (called <I>extensions</I> in Netlogo), and you'll have to download those extra libraries as well. In that case be sure to get the libraries made for NL6! For some simulations the speed in the Netlogo 6 version is slower than in the original Netlogo 4 version, because in newer versions of Netlogo the frame rate is clamped at 30fps.  You can increase the frame rate by moving the upper slider to the right or by choosing another default frame rate altogether in the settings (button northeast). </LI>
</OL>
</P>

<P>
I wish you good luck.
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Thu, 10 Jun 2021 18:22:36 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/netlogo.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
