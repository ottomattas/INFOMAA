<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/some_books.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Some books</H1>

<P align="center">
<TABLE border="0" cellpadding="0" cellspacing="5">
   <TR valign="top">
      <TD width="33.33%"><IMG border="0" width="100%" src="img/133557-L.jpg"/></TD>
      <TD width="33.33%"><IMG border="0" width="100%" src="img/34jhj4he4gjhg.jpg"/></TD>
      <TD width="33.33%"><IMG border="0" width="100%" src="img/975207.jpg"/></TD>
   </TR>
   <TR valign="top">
      <TD width="33.33%"><IMG border="0" width="100%" src="img/5100ZuQeWPL.jpg"/></TD>
      <TD width="33.33%"><IMG border="0" width="100%" src="img/457ds3676dadtrfh2.jpg"/></TD>
      <TD width="33.33%"><IMG border="0" width="100%" src="img/897s978d7889.jpg"/></TD>
   </TR>
   <TR valign="top">
      <TD width="33.33%"><IMG border="0" width="100%" src="img/7466461.jpg"/></TD>
      <TD width="33.33%"><IMG border="0" width="100%" src="img/1001004008498653.jpg"/></TD>
      <TD width="33.33%"><IMG border="0" width="100%" src="img/312735-L.jpg"/></TD>
   </TR>
</TABLE>
</P>

<P>Books that I took with me during the first meeting.</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 02 Apr 2014 16:58:19 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/some_books.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
