<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/netlogo_technology_adoption.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Demo</H1>

<P>
<applet code="org.nlogo.lite.Applet"
        archive="netlogo/NetLogoLite.jar"
        width="936" height="670">
  <param name="DefaultModel"
         value="netlogo/TechnologyAdoption.nlogo">
</applet>
</P>
&copy; Uwe Th&uuml;mmel, 2010.

<H5>WHAT IS IT?</H5>
<P>
A model of technology adaptation according to Peyton Young, Social Dynamics: Theory and applications, Handbook of Computational Economics, Vol. 2, L. Tesfatsion, K.L. Judd (eds.), Elsevier, 2006, 1081-1108
</P>
<H5>HOW IT WORKS</H5>
<P>
There are two technologies, green and red. Agents are represented by patches. The color of a patch indicates the technology used by an agent. Initially, each agent is endowed with one of the technologies. Each period an agent is picked at random. She then decides on her technology in the next period by choosing a random sample of n other agents and comparing expected payoffs for the two technologies. (Coordination game)
</P>
<H5>HOW TO USE IT</H5>
<P>
This section could explain how to use the model, including a description of each of the items in the interface tab.
</P>
<H5>THINGS TO NOTICE</H5>
<P>
This section could give some ideas of things for the user to notice while running the model.
</P>
<H5>THINGS TO TRY</H5>
<P>
Random perturbations: At each period an agent either chooses a technology randomly with probability p, or plays a best response as in the standard model with probability 1-p.
</P>
<P>
Spatial adaptation: Instead of choosing a sample of n agents randomly, an agent compares her technology with the 8 neighboring agents.
</P>
<H5>EXTENDING THE MODEL</H5>
<P>
This section could give some ideas of things to add or change in the procedures tab to make the model more complicated, detailed, accurate, etc.
</P>
<H5>NETLOGO FEATURES</H5>
<P>
This section could point out any especially interesting or unusual features of NetLogo that the model makes use of, particularly in the Procedures tab.  It might also point out places where workarounds were needed because of missing features.
</P>
<H5>RELATED MODELS</H5>
<P>
This section could give the names of models in the NetLogo Models Library or elsewhere which are of related interest.
</P>
<H5>CREDITS AND REFERENCES</H5>
<P>
A model of technology adaptation according to Peyton Young, Social Dynamics: Theory and applications, Handbook of Computational Economics, Vol. 2, L. Tesfatsion, K.L. Judd (eds.), Elsevier, 2006, 1081-1108
</P>
<P>
By Uwe Thuemmel, U.Thummel@students.uu.nl University of Utrecht
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Thu, 24 Apr 2014 22:15:51 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/netlogo_technology_adoption.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>

