<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_hypothesis_testing.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Hypothesis testing</H1>

<P><!-- description -->
People cope with complex learning environments by adopting tentative &ldquo;scripts&rdquo; or &ldquo;schemas&rdquo; to explain what happens.  This point of view is reminiscent of hypothesis testing in classical statistics where a hypothesis is maintained until it is too much contradicted by the data.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_HypothesisTesting.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Jun 12, 2019.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Strategic Learning and its Limits&rdquo; <I>Peyton Young</I> (2004). Ch. 8 [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=strategic+learning+and+its+limits+peyton+young+2004+ch+8" target="_blank">scholar</A>, <A href="lib.php?query=strategic+learning+and+its+limits+peyton+young+2004+ch+8" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Learning, hypothesis testing, and Nash equilibrium&rdquo; <I>Foster &amp; Peyton Young</I> (2003) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+hypothesis+testing+and+nash+equilibrium+foster+peyton+young+2003" target="_blank">scholar</A>, <A href="lib.php?query=learning+hypothesis+testing+and+nash+equilibrium+foster+peyton+young+2003" target="_blank">lib</A>].  Contains additional details and proofs.</LI>
<LI>&ldquo;Hypothesis Testing; Math Bio Boot Camp&rdquo; <I>Vincent A. Voelz</I> (2006) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=hypothesis+testing+math+bio+boot+camp+vincent+a+voelz+2006" target="_blank">scholar</A>, <A href="lib.php?query=hypothesis+testing+math+bio+boot+camp+vincent+a+voelz+2006" target="_blank">lib</A>].  Gives more details on some of the concepts Young discusses, such as
null-hypothesis and Type I errors.</LI>
</OL>
</P>

<H5>Demo</H5>
<P>
<UL>
<LI>
<A href="netlogo_hypothesis_testing.php" target="_blank">Hypothesis Testing</A>.
</LI>
</UL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Thu, 25 Jan 2018 13:29:00 +01001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_hypothesis_testing.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
