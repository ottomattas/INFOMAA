<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_uncoupled_learning.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Uncoupled learning and Nash equilibria</H1>

<P><!-- description -->
There are two important motives to study Nash equilibria in MAL. First, convergence to a Nash equilibrium is a very natural desideratum. If strategies would not converge to a Nash equilibrium, then at least one player does not play a best reply which is short of saying that its learning algorithm is &ldquo;broken&rdquo;. Second, MAL would be of great help if it can put to use to find Nash equilibria.  Unfortunately, all research indicates that MAL and Nash equilibria do not form a happy combination. Nash equilibria's complexity (i.e., PPAD) seems not in line with the often simple MAL algorithms and MAL seems to yield correlated equilibria at best.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_UncoupledLearning.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Jun 18, 2019.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P><!-- <P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
<H2>Slides</H2>
T.B.P.      </TD>
      <TD align="right">
<H2>Assignment</H2> T.B.P.      </TD>
   </TR>
</TABLE>
</P>-->

<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Stochastic uncoupled dynamics and Nash equilibrium&rdquo; <I>S. Hart &amp; A. Mas-Colell</I> (2006) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=stochastic+uncoupled+dynamics+and+nash+equilibrium+s+hart+a+mas+colell+2006" target="_blank">scholar</A>, <A href="lib.php?query=stochastic+uncoupled+dynamics+and+nash+equilibrium+s+hart+a+mas+colell+2006" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Regret testing Learning to play Nash equilibrium without knowing you have an opponent&rdquo; <I>Foster Young (2006)</I> [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=regret+testing+learning+to+play+nash+equilibrium+without+knowing+you+have+an+opponent+foster+young+2006" target="_blank">scholar</A>, <A href="lib.php?query=regret+testing+learning+to+play+nash+equilibrium+without+knowing+you+have+an+opponent+foster+young+2006" target="_blank">lib</A>]</LI>
<LI>&ldquo;The possible and the impossible in multi-agent learning&rdquo; <I>H.P. Young</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+possible+and+the+impossible+in+multi+agent+learning+h+p+young+2007" target="_blank">scholar</A>, <A href="lib.php?query=the+possible+and+the+impossible+in+multi+agent+learning+h+p+young+2007" target="_blank">lib</A>]</LI>
<LI>&ldquo;Completely uncoupled dynamics and Nash equilibria&rdquo; <I>Y. Babichenko</I> (2012) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=completely+uncoupled+dynamics+and+nash+equilibria+y+babichenko+2012" target="_blank">scholar</A>, <A href="lib.php?query=completely+uncoupled+dynamics+and+nash+equilibria+y+babichenko+2012" target="_blank">lib</A>]</LI>
</OL>
</P>

<!--
<H5>Demos</H5>
<P>
<UL>
<LI>
<A href="netlogo_satisficing_play.php" target="_blank">Satisficing Play</A>.
</LI>
</UL>
</P>
-->



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Mon, 22 Jan 2018 09:47:47 +01001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_uncoupled_learning.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
