<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_spatial_adaptation.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Spatial adaptation</H1>

<P><!-- description -->
Spatial models of adaptation assume a space, for example a grid, or a plane, or the surface of a torus.  Agents &ldquo;live&rdquo; in this space and entertain certain preferences as to their location and the location relative to other agents.  There are roughly two types of spatial games, viz. discrete spatial games and differential games.  A discrete spatial game assumes a finite number of locations, strategies and actions.  An advantage of discrete games is that they are mathematically simpler and more accessible than differential games.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P><!-- <P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
<H2>Slides</H2>
T.B.P.      </TD>
      <TD align="right">
<H2>Assignment</H2> T.B.P.      </TD>
   </TR>
</TABLE>
</P>-->

<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;On the Emergence of Cities&rdquo; <I>Page</I> (1999) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=on+the+emergence+of+cities+page+1999" target="_blank">scholar</A>, <A href="lib.php?query=on+the+emergence+of+cities+page+1999" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>Page &amp; Miller (2007). Complex adaptive systems: an introduction to computational models of social life [<A href="http://books.google.nl/books?q=complex+adaptive+systems+computational+models+osocial+life+miller+page" target="_blank">book</A>]</LI>
<LI>
W. Grevers (2008).  <A href="http://doc.utwente.nl/57880/" target="_blank">Land markets and public policy: an act of balance in spatial equilibrium</A>. PhD Thesis</LI>
</OL>
</P>

<H5>Demos</H5>
<P>
<UL>
<LI><A href="netlogo_emergence_of_cities.php" target="_blank">Netlogo demo</A> of Page's Emergence of Cities.</LI>
</UL>
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 02 Apr 2014 16:58:19 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_spatial_adaptation.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
