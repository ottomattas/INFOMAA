<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_evolutionary_games.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Evolutionary game theory</H1>

<P><!-- description -->
An ecosystem is assumed in which populations are represented by a proportion of a mixed strategy (e.g., in the repeated prisoners' dilemma: 40% plays C throughout, 40% plays D throughout, and 20% plays tit-for-tat).
Rounds consist of pairing up strategies in the given proportions, and the idea is that strategies that are most successful, survive.  Evolutionary game theory gives rise to a new type of equilibrium, called an evolutionarily stable strategy (ESS).  It can be proven that an ESS is in some cases related to other equilibrium concepts, such as Nash equilibria and stable rest points of the replicator equation.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_EvolutionaryGames.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;May 15, 2019.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P><!-- <P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
<H2>Slides</H2> T.B.P.      </TD>
      <TD align="right">
<H2>Assignment</H2> T.B.P.      </TD>
   </TR>
</TABLE>
</P>-->

<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;An Introduction to Evolutionary Games&rdquo; <I>Peters</I> (2008). Ch 8 of Game theory A Multi-Levelled Approach [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=an+introduction+to+evolutionary+games+peters+2008+ch+8+of+game+theory+a+multi+levelled+approach" target="_blank">scholar</A>, <A href="lib.php?query=an+introduction+to+evolutionary+games+peters+2008+ch+8+of+game+theory+a+multi+levelled+approach" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Evolutionary Games&rdquo; <I>Peters</I> (2008). Ch 15 of Game theory A Multi-Levelled Approach [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=evolutionary+games+peters+2008+ch+15+of+game+theory+a+multi+levelled+approach" target="_blank">scholar</A>, <A href="lib.php?query=evolutionary+games+peters+2008+ch+15+of+game+theory+a+multi+levelled+approach" target="_blank">lib</A>]</LI>
<LI>&ldquo;Learning and Teaching&rdquo; <I>Shoham</I> (2009). Ch. 7 of Multi-agent Systems [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">scholar</A>, <A href="lib.php?query=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">lib</A>].  Sec. 7.7: &ldquo;Evolutionary learning and other large-population models&rdquo;.</LI>
<LI>&ldquo;An Introduction to Evolutionary Game Theory&rdquo; <I>Rees</I> (2004) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=an+introduction+to+evolutionary+game+theory+rees+2004" target="_blank">scholar</A>, <A href="lib.php?query=an+introduction+to+evolutionary+game+theory+rees+2004" target="_blank">lib</A>].</LI>
<LI>&ldquo;Competition and Cooperation&rdquo; <I>Flake</I> (1998). Ch. 17 of The Computational Beauty of Nature [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=competition+and+cooperation+flake+1998+ch+17+of+the+computational+beauty+of+nature" target="_blank">scholar</A>, <A href="lib.php?query=competition+and+cooperation+flake+1998+ch+17+of+the+computational+beauty+of+nature" target="_blank">lib</A>].  Sec. 17.5:
&ldquo;Ecological and Spatial Worlds&rdquo;</LI>
</OL>
</P>

<H5>Demos</H5>
<P>
<UL>
<LI><A href="netlogo_tournament_evolutionary.php" target="_blank">Netlogo demo</A> of an evolutionary game.</LI>
</UL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Fri, 15 Dec 2017 10:04:23 +01001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_evolutionary_games.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
