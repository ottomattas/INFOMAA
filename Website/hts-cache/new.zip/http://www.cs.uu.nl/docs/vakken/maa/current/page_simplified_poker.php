<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_simplified_poker.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Simplified Poker</H1>

<P><!-- description -->
Card poker (such as Hold'em) is a game of imperfect information where in between rounds (&ldquo;hands&rdquo;) players may adapt to each others' play (if they think that is necessary).  [In poker, change of playing style to disorient opponents is known as &ldquo;shifting gears&rdquo;.]  Although there is scientific work on real-world poker, it is generally acknowledged that real-world poker is too complex for a transparent and exhaustive mathematical analysis.  To this end, more simple versions have been proposed, such as Rhode Island Hold'em and Kuhn poker.  For these types of poker, a number of concrete results have indeed been attained.  Recently (Januari, 2015), it has been claimed that heads-up hold'em has been solved.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P><!-- <P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
<H2>Slides</H2> T.B.P.      </TD>
      <TD align="right">
<H2>Assignment</H2> T.B.P.      </TD>
   </TR>
</TABLE>
</P>-->

<A name="#photos"></A>
<H5>Empirical research</H5>
<P>
<TABLE border="1" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         <A href="photos/sharp/AerealView.jpg" target="_new"><IMG src="photos/AerealView.jpg" width="100%" border="0"/></A>
      </TD>
      <TD>
         <A href="photos/sharp/2PlayersThinking.jpg" target="_new"><IMG src="photos/2PlayersThinking.jpg" width="100%" border="0"/></A>
      </TD>
      <TD>
         <A href="photos/sharp/OnePlayerThinking.jpg" target="_new"><IMG src="photos/OnePlayerThinking.jpg" width="100%" border="0"/></A>
      </TD>
      <TD>
         <A href="photos/sharp/Overview.jpg" target="_new"><IMG src="photos/Overview.jpg" width="100%" border="0"/></A>
      </TD>
   </TR>
</TABLE>
</P>
<P>
<TABLE border="0" cellpadding="3" cellspacing="0" width="100%">
   <TR align="center">
      <TD><I>Various learning techniques (see name tags) were tested
      empirically in the 2nd half of the last meeting in 2011.  (Photo's Shoshannah
      Tekofsky.)</I></TD>
   </TR>
</TABLE>
</P>

<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Regret minimization games with incomplete information&rdquo; <I>Zinkevich et al.</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=regret+minimization+games+with+incomplete+information+zinkevich+et+al+2007" target="_blank">scholar</A>, <A href="lib.php?query=regret+minimization+games+with+incomplete+information+zinkevich+et+al+2007" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;The Challenge of Poker&rdquo; <I>Billings et al.</I> (2002) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+challenge+of+poker+billings+et+al+2002" target="_blank">scholar</A>, <A href="lib.php?query=the+challenge+of+poker+billings+et+al+2002" target="_blank">lib</A>]</LI>
<LI>&ldquo;Optimal Rhode Island Hold em Poker&rdquo; <I>Gilpin &amp; Sandholm</I> (2005) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=optimal+rhode+island+hold+em+poker+gilpin+sandholm+2005" target="_blank">scholar</A>, <A href="lib.php?query=optimal+rhode+island+hold+em+poker+gilpin+sandholm+2005" target="_blank">lib</A>]</LI>
<LI>&ldquo;Perspectives on multiagent learning&rdquo; <I>Sandholm</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=perspectives+on+multiagent+learning+sandholm+2007" target="_blank">scholar</A>, <A href="lib.php?query=perspectives+on+multiagent+learning+sandholm+2007" target="_blank">lib</A>]</LI>
<!--<LI>&ldquo;An adaptive learning model for simplified poker using evolutionary algorithms&rdquo; <I>Barone et al.</I> (1999) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=an+adaptive+learning+model+for+simplified+poker+using+evolutionary+algorithms+barone+et+al+1999" target="_blank">scholar</A>, <A href="lib.php?query=an+adaptive+learning+model+for+simplified+poker+using+evolutionary+algorithms+barone+et+al+1999" target="_blank">lib</A>]</LI>-->
<LI>&ldquo;Monte Carlo Sampling for Regret Minimization in Extensive Games&rdquo; <I>Lanctot et al.</I> (2009) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=monte+carlo+sampling+for+regret+minimization+in+extensive+games+lanctot+et+al+2009" target="_blank">scholar</A>, <A href="lib.php?query=monte+carlo+sampling+for+regret+minimization+in+extensive+games+lanctot+et+al+2009" target="_blank">lib</A>]</LI>
<LI>&ldquo;Heads-up limit hold em poker is solved&rdquo; <I>Bowling et al.</I> (2015) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=heads+up+limit+hold+em+poker+is+solved+bowling+et+al+2015" target="_blank">scholar</A>, <A href="lib.php?query=heads+up+limit+hold+em+poker+is+solved+bowling+et+al+2015" target="_blank">lib</A>]</LI>
</OL>
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 18 Mar 2015 21:24:44 +01001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_simplified_poker.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
