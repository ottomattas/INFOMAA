<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_ant_colony.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Ant colony optimisation (ACO)</H1>


<H3>New description</H3>
<P><!-- description -->
Ant colony optimisation (ACO) is an interesting way to let ants together find a solution for NP-complete problems.
</P>
<P>
The old descripton (from 2013) follows now. I think, due to the tone of the old description, nobody selected ACO at that time.  If you decide to put ACO on your list of preferred topics, I would welcome it very much.  Rest assured that in such case I will judge your presentation and the paper, not the topic itself.
</P>

<H3>Old description</H3>
<P>
Would it not be a nice idea to let ants learn and solve your problem?  Proponents of ant colony optimisation (ACO) claim just that.
ACO is not really multi-agent learning (ants essentially perform the same task), but it comes close.  The reason to include ACO in a MAL seminar is that ACO is a popular topic that appeals to the imagination.  Your instructor is rather sceptical about ACO.  According to me, ACO boils down to combinatorial optimisation (an established field devoid of ants and agents) pimped with ants and pheromones.   The ants are just there to spice things up a bit.  Prove that your sceptical teacher is wrong, and show that ACO <I>is</I> about learning and adaptivity, and that ants can't be missed from the picture.<!-- As an example, it is possible to give valid presentations that discuss the ins and outs of quantum computing.  Or tri-secting angles (with a compass and a ruler alone), the Pope, UFOs, artificial intelligence, and other paranormal phenomona. -->
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Ant colony optimization. Overview and recent advances&rdquo; <I></I> (2010) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=ant+colony+optimization+overview+and+recent+advances+dorigo+st+tzle+2010" target="_blank">scholar</A>, <A href="lib.php?query=ant+colony+optimization+overview+and+recent+advances+dorigo+st+tzle+2010" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI><A href="http://en.wikipedia.org/wiki/Ant_colony_optimization_algorithms" target="_blank">Wikipedia page on ACO</A></LI>
<LI><A href="http://www.cs.uu.nl/docs/vakken/ias/" target="_blank">Inleiding adaptieve systemen</A> is a first-year bachelor course on adaptive systems, and has a powerpoint on powerpoint on <A href="http://www.cs.uu.nl/docs/vakken/ias/slides/IAS%2003%20-%20Zelf-organisatie%20en%20Emergentie.ppt" target="_blank">ACO</A> [in Dutch].<IMG style="position: fixed; z-index: 100" src="img/vlieg.gif"/></LI>
<LI>&ldquo;Ant colony optimization&rdquo; <I>Dorigo et al.</I> (2006) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=ant+colony+optimization+dorigo+et+al+2006" target="_blank">scholar</A>, <A href="lib.php?query=ant+colony+optimization+dorigo+et+al+2006" target="_blank">lib</A>]</LI>

</OL>
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 29 Mar 2017 18:19:16 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_ant_colony.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
