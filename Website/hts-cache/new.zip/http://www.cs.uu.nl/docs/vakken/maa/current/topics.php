<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/topics.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Topics</H1>

<P>For reference's sake here is a list of all topics that were discussed in the past years.  The first few entries in the left column correspond to the chapters of H. Peyton Youngs' monography &ldquo;Strategic Learning and its Limits&rdquo; (2004).</P>
<P>
<TABLE border="0" cellpadding="0" cellspacing="0">
   <TR valign="top">
      <TD>
         <DL>
   <DT><FONT class="topic">Introduction</FONT></DT>
<DD>
Several examples of multi-agent learning will be played live and discu ... [<A href="page_introduction.php">more</A>]
</DD><!--Various topics-->
   <DT><FONT class="topic">Essentials of game theory</FONT></DT>
<DD>
Game theory (as: &ldquo;Von-Neumann-Morgenstern economic game theory&r ... [<A href="page_game_theory.php">more</A>]
</DD><!--Game theory-->
   <DT><FONT class="topic">Repeated games</FONT></DT>
<DD>
Much interaction in multi-agent systems can be modelled through games  ... [<A href="page_repeated_games.php">more</A>]
</DD><!--Chapter of H. Peters-->
   <DT><FONT class="topic">Multi-armed bandit algorithms</FONT></DT>
<DD>
A multi-armed bandit algorithm learns a game, just by observing the pa ... [<A href="page_bandit_algorithms.php">more</A>]
</DD><!--Multi-armed bandit-->
   <DT><FONT class="topic">Reinforcement learning</FONT></DT>
<DD>
Reinforcement learning plays actions with the highest past payoff.  Wh ... [<A href="page_reinforcement_learning.php">more</A>]
</DD><!--H.P. Young plus work of Beggs-->
   <DT><FONT class="topic">No-regret learning</FONT></DT>
<DD>
No-regret learning is a natural extension of reinforcement learning.   ... [<A href="page_no_regret.php">more</A>]
</DD><!--No regret-learning-->
   <DT><FONT class="topic">Types of equilibria</FONT></DT>
<DD>
Some multi-agent learning algorithms, such as
regret matching (RM, Har ... [<A href="page_equilibria.php">more</A>]
</DD><!--correlated equilibria-->
   <DT><FONT class="topic">Conditional no-regret</FONT></DT>
<DD>
A player has regret if it could have earned more by playing a certain  ... [<A href="page_conditional_no_regret.php">more</A>]
</DD> <!-- Conditional no-regret-->
   <DT><FONT class="topic">Prediction, postdiction, and calibration</FONT></DT>
<DD>
Like fictitious play and Bayesian learning, calibration tries to predi ... [<A href="page_calibration.php">more</A>]
</DD><!--Calibration-->
   <DT><FONT class="topic">Fictitious play</FONT></DT>
<DD>
Fictitious play works by sampling the actions of the opponent(s), and  ... [<A href="page_fictitious_play.php">more</A>]
</DD><!--Fictitious play-->
   <DT><FONT class="topic">Bayesian learning</FONT></DT>
<DD>
Bayesian Learning, also known as rational learning, applies Bayes' rul ... [<A href="page_bayesian_learning.php">more</A>]
</DD><!--Bayesian Learning-->
   <DT><FONT class="topic">Hypothesis testing</FONT></DT>
<DD>
People cope with complex learning environments by adopting tentative & ... [<A href="page_hypothesis_testing.php">more</A>]
</DD><!--Hypothesis testing-->
   <DT><FONT class="topic">Satisficing play</FONT></DT>
<DD>
Satisficing play is reinforcement learning with the past average payof ... [<A href="page_satisficing.php">more</A>]
</DD><!--Satisficing multi-agent learning-->
   <DT><FONT class="topic">Evolutionary dynamics in spatial games</FONT></DT>
<DD>
Symmetric strategic games in normal form behave differently when playe ... [<A href="page_spatial_evolution.php">more</A>]
</DD><!--Nowak and such-->
   <DT><FONT class="topic">Multi-agent reinforcement learning</FONT></DT>
<DD>
Reinforcement learning can be used, not only to evaluate one's own act ... [<A href="page_MARL.php">more</A>]
</DD><!--Multi-agent reinforcement learning-->
   <DT><FONT class="topic">Stochastic games</FONT></DT>
<DD>
A stochastic game (also: Markov game) is a generalisation of the conce ... [<A href="page_stochastic_games.php">more</A>]
</DD><!--Stochastic Games-->
   <DT><FONT class="topic">Evolutionary game theory</FONT></DT>
<DD>
An ecosystem is assumed in which populations are represented by a prop ... [<A href="page_evolutionary_games.php">more</A>]
</DD><!--Evolutionary game theory-->
   <DT><FONT class="topic">Replicator dynamics</FONT></DT>
<DD>
T.b.a. ... 
</DD><!--replicator equation in vitro-->
   <DT><FONT class="topic">Emergence of social conventions</FONT></DT>
<DD>
It is studied how (typically large) agent populations that use differe ... [<A href="page_social_conventions.php">more</A>]
</DD><!--Emergence of social conventions-->
         </DL>
      </TD>
      <TD>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</TD>
      <TD>
         <DL>
   <DT><FONT class="topic">Methodology of MAL research</FONT></DT>
<DD>
It is important to be clear on the objectives of research in multi-age ... [<A href="page_methodology.php">more</A>]
</DD><!--Methodoloy of multi-agent learning-->
   <DT><FONT class="topic">Real-valued spatial games</FONT></DT>
<DD>
A real-valued spatial game is a variant of a discrete-valued spatial g ... [<A href="page_alife_cellular_automata.php">more</A>]
</DD><!--Spatial models-->
   <DT><FONT class="topic">Cournot Dynamics</FONT></DT>
<DD>
We consider adaptation in repeated two-player games with real-valued a ... [<A href="page_cournot_dynamics.php">more</A>]
</DD><!--Cournot Dynamics-->
   <DT><FONT class="topic">Win-stay lose-shift</FONT></DT>
<DD>
Meet Pavlov. This strategy is as simple as tit-for-tat and embodies th ... [<A href="page_winstay_loseshift.php">more</A>]
</DD> <!-- Pavlov -->
   <DT><FONT class="topic">Gradient dynamics</FONT></DT>
<DD>
Gradient dynamics refers to an approach where players are identified w ... [<A href="page_gradient_dynamics.php">more</A>]
</DD><!--Work of bowling and veloso-->
   <DT><FONT class="topic">Learning games in extensive form</FONT></DT>
<DD>
Games in extensive form are games were moves are executed in successio ... [<A href="page_extensive_form.php">more</A>]
</DD><!--Learning in extensive games-->
   <DT><FONT class="topic">When to teach and when to follow</FONT></DT>
<DD>
Agents in a MAL environment must be able to decide when to teach and w ... [<A href="page_teach_and_follow.php">more</A>]
</DD><!--When to teach and when to follow-->
   <DT><FONT class="topic">Comparing MAL algorithms empirically</FONT></DT>
<DD>
Until 2005, say, MAL research was typically done this way: (1) invent  ... [<A href="page_tournament.php">more</A>]
</DD><!--Empirically comparing MAL algorithms-->
   <DT><FONT class="topic">Simplified Poker</FONT></DT>
<DD>
Card poker (such as Hold'em) is a game of imperfect information where  ... [<A href="page_simplified_poker.php">more</A>]
</DD><!--Simplified poker-->
   <DT><FONT class="topic">Ant colony optimisation (ACO)</FONT></DT>
<DD>
Ant colony optimisation (ACO) is an interesting way to let ants togeth ... [<A href="page_ant_colony.php">more</A>]
</DD><!--Ant colony optimisation-->
   <DT><FONT class="topic">Slime mold mechanisms</FONT></DT>
<DD>
Slime mold is a broad term describing organisms that grow selectively  ... [<A href="page_slime_mold.php">more</A>]
</DD><!--Slime mold mechanisms-->
   <DT><FONT class="topic">Particle swarm optimisation</FONT></DT>
<DD>
Particle swarm optimisation (commonly abbreviated as PSO) is an optimi ... [<A href="page_particle_swarm.php">more</A>]
</DD><!--Particle swarm optimization-->
   <DT><FONT class="topic">Periodicity and chaos in evolutionary dynamics</FONT></DT>
<DD>
It is well known that all interesting symmetric 2&times;2 games like t ... [<A href="page_replicator_lyapunov.php">more</A>]
</DD><!--Periodic and Lyapunov properties of a discrete  replicator equation-->
   <DT><FONT class="topic">The CLRI framework</FONT></DT>
<DD>
CLRI (the letters correspond to the first letters of the parameters' n ... [<A href="page_CLRI.php">more</A>]
</DD><!--CLRI Framework-->
   <DT><FONT class="topic">Joint process games: from ratings to wikis</FONT></DT>
<DD>
In 2010 PhD student Michael Munie (now engineer at Google in Paris) an ... [<A href="page_wiki_games.php">more</A>]
</DD><!--Wiki games-->
   <DT><FONT class="topic">Argumentation-based MAL</FONT></DT>
<DD>
Enrique Plaza is one of the few researchers who unites the areas of mu ... [<A href="page_argumentation.php">more</A>]
</DD><!--Argumentation-based approach to MAL (Plaza) -->
   <DT><FONT class="topic">Spatial adaptation</FONT></DT>
<DD>
Spatial models of adaptation assume a space, for example a grid, or a  ... [<A href="page_spatial_adaptation.php">more</A>]
</DD><!--Spatial adaptation-->
   <DT><FONT class="topic">Uncoupled learning and Nash equilibria</FONT></DT>
<DD>
There are two important motives to study Nash equilibria in MAL. First ... [<A href="page_uncoupled_learning.php">more</A>]
</DD><!---->
      </TD>
   </TR>
</TABLE>
</P>

<P>
*There is a diagram to suggest <A href="diagram.php">interdependence</A> among the topics.
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Thu, 30 Apr 2020 14:12:53 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/topics.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
