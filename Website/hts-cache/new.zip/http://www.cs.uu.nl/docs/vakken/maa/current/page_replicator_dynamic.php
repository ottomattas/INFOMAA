<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_replicator_dynamic.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>The replicator dynamic</H1>


<P><!-- description -->
The replicator dynamic imagines how species (of any kind) evolve if they interact through competition, and grow proportionally to their success.  When the replicator equation is mentioned, usually the continuous version is meant, but the discrete version is just as interesting, and actually more relevant for multi-agent learning in computer science.</P>
<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_ReplicatorDynamic.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Jun 14, 2021.
      </TD>
      <TD>
<H2>Screencast</H2> <A href="https://www.youtube.com/playlist?list=PL8AyDiByAbIQkg5zIzZ0-F3HNI8tM2lIV" target="_blank">Youtube</A>
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Replicator Dynamics in Discrete and Continuous Strategy Spaces&rdquo; <I>R. Westra &amp; K. Tuyls</I> (2009) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=replicator+dynamics+in+discrete+and+continuous+strategy+spaces+r+westra+k+tuyls+2009" target="_blank">scholar</A>, <A href="lib.php?query=replicator+dynamics+in+discrete+and+continuous+strategy+spaces+r+westra+k+tuyls+2009" target="_blank">lib</A>]</LI>
</UL>
</P>

<H5>Support</H5><!-- Support -->
<P>
<UL>
<LI>Opgaven en uitwerkingen van <A href="http://www.cs.uu.nl/docs/vakken/ias/stuff/IAS_werkcollege_2017.pdf" target="_blank">Hoofdstuk 13: Replicator-dynamiek</A> van werkcollegedictaat IAS.  (In Dutch.)</LI>
<LI>&ldquo;The replicator equation and other game dynamics&rdquo; <I>Cressman and Tao</I> (2014) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+replicator+equation+and+other+game+dynamics+cressman+and+tao+2014" target="_blank">scholar</A>, <A href="lib.php?query=the+replicator+equation+and+other+game+dynamics+cressman+and+tao+2014" target="_blank">lib</A>]</LI>
<LI>&ldquo;Learning and Teaching&rdquo; <I>Shoham</I> (2009). Ch. 7 of Multi-agent Systems [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">scholar</A>, <A href="lib.php?query=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">lib</A>]</LI>
<LI>&ldquo;Competition and Cooperation&rdquo; <I>Flake</I> (1998). Ch. 17 of The Computational Beauty of Nature [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=competition+and+cooperation+flake+1998+ch+17+of+the+computational+beauty+of+nature" target="_blank">scholar</A>, <A href="lib.php?query=competition+and+cooperation+flake+1998+ch+17+of+the+computational+beauty+of+nature" target="_blank">lib</A>]</LI>
</LI>
</UL>
</P>

<H5>Demos</H5>
<P>
<UL>
<LI><A href="netlogo_replicator_dynamic.php" target="_blank">Netlogo demo</A> of the discrete replicator equation.</LI>
<LI><A href="netlogo_replicator_dynamic_bifurcation.php" target="_blank">Netlogo demo</A> of bifurcation diagrams of the discrete replicator equation.</LI>
</UL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Tue, 02 Jun 2020 13:46:34 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_replicator_dynamic.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
