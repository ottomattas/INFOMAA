<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_bayesian_learning.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Bayesian learning</H1>

<P><!-- description -->
Bayesian Learning, also known as rational learning, applies Bayes' rule to the realised history vs. the set of all possible histories.  Bayesian learning is also called rational learning because conditioning on all possible histories allows players to take into account all strategy scenarios that are theoretically possible given past play.   Thus, actors are assumed to be perfectly rational.  Under certain conditions it can be proven that a player's beliefs will eventually converge to actual play if it uses Bayesian
updating, and plays a best response strategy.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_BayesianLearning.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Jun  2, 2021.
      </TD>
      <TD>
<H2>Screencast</H2> <A href="https://www.youtube.com/playlist?list=PL8AyDiByAbISJVJGViMkAeqO_wijP--0i" target="_blank">Youtube</A>
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Learning and Teaching&rdquo; <I>Shoham</I> (2009). Ch. 7 of Multi-agent Systems [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">scholar</A>, <A href="lib.php?query=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">lib</A>].  Sec. 7.3</LI>
<LI>&ldquo;Strategic Learning and its Limits&rdquo; <I>Peyton Young</I> (2004). Ch. 7 [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=strategic+learning+and+its+limits+peyton+young+2004+ch+7" target="_blank">scholar</A>, <A href="lib.php?query=strategic+learning+and+its+limits+peyton+young+2004+ch+7" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Introduction to Probability Models&rdquo; <I>Sheldon Ross</I> (2007). Ch. 1 [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=introduction+to+probability+models+sheldon+ross+2007+ch+1" target="_blank">scholar</A>, <A href="lib.php?query=introduction+to+probability+models+sheldon+ross+2007+ch+1" target="_blank">lib</A>].  (Basic probability and Bayes' rule.)</LI>
<LI>&ldquo;Bayesian Learning in Negotiation&rdquo; <I>Zeng &amp; Sycara</I> (1996) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=bayesian+learning+in+negotiation+zeng+sycara+1996" target="_blank">scholar</A>, <A href="lib.php?query=bayesian+learning+in+negotiation+zeng+sycara+1996" target="_blank">lib</A>]</LI>
<LI>&ldquo;Kalai &amp; Lehrer&rdquo; <I>Rational Learning Leads to Nash Equilibrium</I> (1993) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=kalai+lehrer+rational+learning+leads+to+nash+equilibrium+1993" target="_blank">scholar</A>, <A href="lib.php?query=kalai+lehrer+rational+learning+leads+to+nash+equilibrium+1993" target="_blank">lib</A>]  <FONT class="marked">This is the original paper and used to be the key paper in the seminars of 2010 and 2011</FONT>.</LI>
<LI>&ldquo;Merging of Opinions with Increasing Information&rdquo; <I>Blackwell &amp; Dubins</I> (1962) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=merging+of+opinions+with+increasing+information+blackwell+dubins+1962" target="_blank">scholar</A>, <A href="lib.php?query=merging+of+opinions+with+increasing+information+blackwell+dubins+1962" target="_blank">lib</A>]</LI>
</OL>
</P>

<H5>Demo</H5>
<P>
<UL>
<LI>
<A href="netlogo_bayesian_learning.php" target="_blank">Bayesian Learning</A>.
</LI>
</UL>
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Tue, 11 Jun 2019 11:21:32 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_bayesian_learning.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
