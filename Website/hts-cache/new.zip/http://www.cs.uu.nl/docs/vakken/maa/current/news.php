<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/news.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>News</H1>


<DL>

<DT>June 08</DT><DD>
<LI>Link to Youtube playlist &ldquo;A similar BSc programming assignment&rdquo; corrected.  (In the meantime you already found the presentation video through a back door I suppose.) In the video (which is from 2020) it is said &ldquo;since there are no longer exams&rdquo;. We know this is not true for 2021, where there is a  written end term.  (In 2020 students had to complete several homework assignments, which was a lot of work.)</LI>
</DD>

<DT>June 01</DT><DD>
<LI>On occasion of a question on the slides on Gradient Dynamics in the Q&amp;A session today, added a second slide to &ldquo;Part 4: Another solution&rdquo; with the actual equations.</LI>
<LI>On occasion of a question on MC12 of the mid term exam in the Q&amp;A session today (&ldquo;Does exponentiated regret matching depend on past play of opponents?&rdquo;), added some explanation to the answer of this question.</LI>
<LI>On occasion of a remark on the grading scale today, changed the phrase &ldquo;2 points free and 1.02 scaling&rdquo; into &ldquo;1.02 scaling, then 2 points free&rdquo;, so as to make the description match the formula.</LI>
</DD>

<DT>May 31</DT><DD>
<LI>Grades mid term published in <A href="https://uu.blackboard.com" target="_blank">Blackboard</A>.  Apologies for the two decimals precision (second decimal should always be zero), this is Blackboard.  Mid term maximum nr. of points: 16; grade: 9*(1.02*points+2)/16+1 [1.02 scaling, then 2 points free]; grades: 3.8, 4.1, 4.4, 4.9, 5.2, 5.3, 5.7, 5.7, 5.9, 6, 6.1, 6.7, 6.7, 6.9, 7, 7.2, 7.3, 7.3, 7.6, 7.6, 7.6, 7.6, 7.9, 7.9, 7.9, 7.9, 8.1, 8.4, 8.4, 8.6, 8.7, 8.7, 9.9, 10. Opportunity to examine own answer sheet and grading: Thursday June 3, end of lecture.</LI>
</DD>

<DT>May 27</DT><DD>
<LI>{ Corrections of / additions to } answers mid term (thanks for the feedback): OPEN2 (Arthur), MC3 (UCB deterministic?).  For explanation and consequences for grading, see the exam.</LI>
</DD>

<DT>May 26</DT><DD>
<LI>Answers mid term published at &ldquo;Old exams&rdquo; (left margin).</LI>
<LI>Jiayuan and Adri&aacute;n published the programming assignment on blackboard. It is already possible to ask questions, also on blackboard.  It is perfectly OK to postpone paying attention to the program assignment until after the mid term exam (<TT>#timemanagement</TT>). On Thursday June 3, Adri&aacute;n and Jiayuan will briefly explain the assignment, and answer remaining questions.</LI>
</DD>

<DT>May 25</DT><DD>
<LI>To be on the safe side, I repeat that there are no lectures today.</LI>
<LI>Changed <I>&alpha;a + &beta;b + &gamma;c + &delta;d</I> into <I>&alpha;a' + &beta;c' + &gamma;b' + &delta;d'</I>, in the last two of four inequalities in the middle of Slide 40 on &ldquo;Equilibria&rdquo;. See also the payoff matrix on Slide 38, in particular the pairs <I>(b, c')</I> and <I>(b', c)</I>.</LI>
<LI>The U.S.C.K.I. asked me to promote <A href="https://symposium.uscki.nl/" target="_blank">their next symposium</A> on Friday June 4, which is about <A href="uscki/2021/ProgrammaboekjeSympo2021.jpg" target="_blank">gaming and gamification</A>.  Here a <A href="uscki/2021/PromoVideoSympo2021.mp4" target="_blank">promo video</A>.</LI>
</DD>

<DT>May 20</DT><DD>
<LI>Supplemental slides fictitious play published.</LI>
</DD>

<DT>May 19</DT><DD>
<LI>The exam room is reserved for 2.5 hours.  The exam lasts two hours, with 30 min extension voor students with a disability.</LI>
<LI>As discussed/indicated online, Part 3 on No-regret is not examined.</LI>
<LI>In old exams, you will find questions on topics that were not discussed in the Youtube lectures.  One such topic is &ldquo;Nash equilibria in repeated games&rdquo;.  These topics are not examined.</LI>
<LI>For both written exams it is allowed to bring a two-sided written or printed note sheet of A4 size. Everything on that sheet must be authentic, i.e. written by yourself. Your note sheet may contain tables or figures, but not copy-pasted. Because the sheet is 2-sided, during the exam I may ask to turn over your sheet. Notes with copy-pasted material are likely to be collected during the exam---like I did in previous exams.  This may be stressful because no matter how discreetly the removal is carried out, it may distract you from focusing on the exam.</LI>
<LI>Slides on Equilibria: added &ldquo;For 2x2 games, CE and CCE coincide&rdquo;, as discussed.</LI>
<LI>Slides on No-regret: repaired Slide 16.</LI>
</DD>


<DT>May 16</DT><DD>
<LI>Slides on Equilibria: page 34 repaired: the <I>+1&delta;</I>'s are changed into <I>-1&delta;</I>'s.  This modification has major consequences for the ensuing CCE which now coincide with the CE.  For 2x2 games the latter is always the case.  At page 38 an example is included where NE &sub; CE &sub; CCE, see also PY, SLaiL, Ch. 3, p. 34.  Tuesday I will explain briefly.</LI>
<LI>Was in the process of programming a Netlogo 6 demo that displayed the CE and CCE of 2x2 games, and their set-theoretic difference in a <A href="https://en.wikipedia.org/wiki/Simplex" target="_blank">3-simplex</A> (neat way to express the four probabilities &alpha;, &beta;, &gamma;, &delta; of a {C}CE in 3D).  Would be cool if it weren't that, as said, for 2x2 games CE and CCE coincide ...</LI>
</DD>

<DT>May 12</DT><DD>
<LI>Added &ldquo;Comparison of reinforcement algorithms&rdquo; to <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo-web.php" target="main">Netlogo 6 page</A>.  Unfortunately, if the program runs in the browser, the plot proceeds so slow that CPM recovering is not observable anymore---which is the whole point of the program.  To obtain a progressing plot and see CPM recover, download the model and run it in NL6 proper.</LI>
</DD>

<DT>May 11</DT><DD>
<LI>Slides on Equilibria: page 7 repaired.</LI>
<LI>Slides on Equilibria: added 37-39 to give examples of CCE that aren't CE.  (In response to a question in Tuesday's meeting.)</LI>
<LI>The programming assignment will be pusblished in the Week of Pentacost, so Tuesday May 25.  I understand that you may have a wish to work ahead, but as I explained in today's meeting, I do not want to let the programming assignment take up too much of your attention in the beginning of the course.</LI>
</DD>



<DT>May 06</DT><DD>
<LI>Supplemental slides multi-agent reinforcement learning published.</LI>
</DD>

<DT>April 29</DT><DD>
<LI>The programming assignment may be executed individually or in pairs.  If the assignment is done in pairs, the final report must contain a section with a description of division of tasks.</LI>
</DD>

<DT>April 28</DT><DD>
<LI>Welcome to the 2FA-less multi-agent learning course site, also on behalf of the two TA's Jiayuan Hu, Adri&aacute;n Rodriguez Otero.</LI>
<LI>In the following we make a distinction between lectures and sessions.  With lectures, we mean the online leactures on the MAA CS Utrecht Youtube channel as referred to on blackboard.  With sessions we mean the live meetings on Tuesdays (online) and Thursdays (Uithof).</LI>
<LI>Sessions Tuesday and Thursday will discuss lectures of <A href="http://www.cs.uu.nl/docs/vakken/maa/current/schedule.php" target="main">the topic of the day</A>. You are supposed to have studied the corresponding Youtube lectures prior to these sessions, AND the corresponding slides AND the literature on the topic page, as the sessions proceed from there.</LI>
<LI>Within sessions, there is ample room for questions and discussion.  At times, an exam problem will be discussed.  At other times, aspects of the programming assignment will be discussed.</LI>
<LI>Sessions start April 29, 09.00-10.45 in Ruppert Blauw.  In line with the previous point I expect you to prepare by watching the Youtube intro lectures.</LI>
<LI>Subsequent Thursday sessions, after April 29, are scheduled on campus in room BBG-219.</LI>
<LI>Tuesday sessions remain online, MS Teams key code on blackboard.</LI>
<LI>Neither physical nor online sessions will be streamed or recorded.</LI>
<LI>Uname/password combo for copyrighted material also on blackboard.</LI>
</DD>

<!--

<DT>July 11</DT><DD>
<LI><A href="restricted/MAL_2020_07_11_12_01.pdf" target="_blank">End grades published</A>.  Same username/password-combo as for retrieving course material on this site, and mailed to you at the outset of this course.  The &ldquo;Phrase&rdquo; columns refer to the first few words of the first sentence of your first question's motivation in the written assignment, and the first few words of the first sentence of the introduction in the programming assignment. Quotes are unique, so in this way you can track down your entry.  The formula for the end grade is <CODE>=IF(Raw&lt3.5,"NVD",IF(Raw&lt;6,ROUND(Raw,0),ROUND(2*Raw,0)/2))</CODE>.  Please allow some time for the end grades to get to Osiris.</LI>
<LI>Thanks for participating, hope to see you on campus soon.  Enjoy your holidays, keep safe.</LI>
<LI>Retake: see the &ldquo;Schedule&rdquo; page on this site.</LI>
</DD>


<DT>June 29</DT><DD>
<LI>Thanks for submitting your work!  A quick browse through the code and documentation already revealed that many of you made something good of this.  We saw subtle strategies, pleasurable plots, tantalizing tables, and agreeable analyses.</LI>
<LI>Please allow us and particularly Yolan some time to process the results of your hard labour.  Expect feedback in 10 work days, that is around Monday, July 13, 2020.</LI>
<LI>The gates to Caracal may already be open.  Yolan and I very much like to know how you experienced the course, for better or for worse.  If you have points for improvement, please let us know.  If you think something was particularly good about the course, then let us know as well.</LI>
<LI>So, until Monday, July 13, then.</LI>
</DD>

<DT>June 23</DT><DD>
<LI>Hope you are doing well, with the assignment and in general.  From the fora I inferred that not all of you discovered that the last presentation indeed discusses work of Zawadzki <I>et al.</I>, Bouzy <I>et al.</I>, and Airiau <I>et al.</I>   But now you know if you didn't already.</LI>
<LI>Read Yolan's recommendations on the forum and take them to heart! </LI>
<LI>If you have time constraints: rule of thumb is to drop programming and focus on the study document.</LI>
</DD>

<DT>June 21</DT><DD>
<LI>Longest day!  Screencast and slides published on comparing MAL algorithms empirically.   Among others, this presentation provides material for the related work section of your study document.  In particular, this presentation tries to sell the idea that taking the set of NE on the grand table as an outcome of comparing different algorithms empirically, is perhaps one of the most prudent methods of comparison.  Yolan and I are curious about your thoughts on this, and we look forward to your considerations and arguments.</LI>
</DD>

<DT>June 18</DT><DD>
<LI>Friday morning, and possibly also a substantial part of the afternoon, Yolan moves to a new appartment and has less time for answering questions.  If you have urgent questions make sure you post them today.</LI>
<LI>Screencast and slides on Bully published: a verbal definition, an example, and a precise definition (16 minutes total).</LI>
</DD>


<DT>June 16</DT><DD>
<LI>Screencast and slides on satisficing play published.  This presentation helps to better understand the algorithm by means of three demos. Further, it provides material for your study document.</LI>
<LI>Netlogo 6 examples on satisficing play published. Because none of these examples use external libraries, they're all directly runnable from within the browser.</LI>
</DD>

<DT>June 15</DT><DD>
<LI><A href="comments.php?year=2020&nr=1" target="main">Feedback to written assignment</A> published.  As opposed to an earlier announcement, there was no need to send grades in personal mails.</LI>
<LI>Grading scheme for the programming assignment published.  This is to be found in the course schedule on this site, at Week 26.</LI>
<LI>The number of questions on the programming assignment grows at a steady pace.  To relieve Yolan I warmheartedly invite you to participate in the discussion and answer questions of co-students whenever possible.  Of course, Yolan keeps monitoring the questions and will provide ultimate answers eventually if necessary.  Thank you.</LI>

<LI>Expect feedback by the beginning of Tuesday 16.  Two concept exams to go, then adding extra feedback to hitherto somewhat sparingly commented concept exams, then spelling correction and editing, then to write a script that sends feedback by mail (thank you Dutch personal data protection act), then test script and actually send the mail.</LI>
</DD>

<DT>June 10</DT><DD>
<LI>Screencast and slides on the replicator dynamic published.  Although this presentation is more theoretical than the previous presentation (the one on a similar BSc programming assignment), it nevertheless contains facts and clues that are important for the current MSc programming assignment.</LI>
</DD>

<DT>June 09</DT><DD>
<LI>Hope you are doing well. Grading on the written assignments is on schedule.  Expect a brief review and a grade no later than Monday June 15.</LI>
<LI>Overall, the assigment is made pretty well.  Still, I want to share one curious phenomenon.  In many cases I encountered a question of the following type: <I>&ldquo;Which of the following <I>N</I> statements are true?&rdquo;</I>  (<I>N</I> somewhere between <I>4</I> and <I>16</I>, inclusive).  You know such questions have <I>2<SUP>N</SUP></I> possible answers and <I>2<SUP>N</SUP> &minus; 1</I> wrong answers?  One question asked to put crosses in the right places of a <I>5&times;6</I> table.  So here we have <I>2<SUP>5&times;6</SUP> = 1073741824</I> possible answers.  Grading such a table requires a dose of tolerance if the grading were for real, but such flexibility was not referred to in the elaboration of the answer.  For the record, I assumed the composer of the concept exam had such flexibility in mind and all was good.</LI>
<LI>Yolan and I work on a grading scheme for the programming assignment, which is planned to be published in the beginning of next week.</LI>
<LI>Besides struggling with &#128013;, please <I>do</I> watch the screencast on a similar BSc programming assignment.  It helps you to take some distance and it helps putting things in perspective.</LI>
</DD>

<DT>June 06</DT><DD>
<LI>Screencast and slides on a similar BSc programming assignment published.</LI>
<LI>Netlogo 6 web examples on a similar BSc programming assignment published.  Please notice that <CODE>Replicator dynamic (evolutionary dynamics) - phase space.nlogo</CODE> and <CODE>PD Axelrod Tournament - Evolutionary (w. Nash).nlogo</CODE> call the Gambit executable and are therefore not executable on the web.  I encourage you to download and run them.  (Before you do, check the app's path to <CODE>gambit-enummixed</CODE>).  Linux and Mac users may need to modify, in the downloaded Netlogo source, the OS call string to Gambit, cf. the forum discussing the Python assignment.</LI>
</DD>

<DT>June 02</DT><DD>
<LI>Official start of the programming assignment.  More details on the &ldquo;Schedule&rdquo; page.</LI>
<LI>Read the messages published on May 29 if you didn't already.</LI>
<LI>Grading of the assignment goes slower than expected.  So a grading period of 10 working days seems realistic after all. Expect a brief review and a grade no later than Monday June 15.</LI>
</DD>

<DT>May 30</DT><DD>
<LI>Thank you for submitting your assignment.  <STRIKE>Please expect a brief review and a grade no later than Friday June 12.</STRIKE></LI>
<LI>If you missed out on the written assignment there is a compensation assignment due Fri July 10th 23:59. The compensation assignment will be published Monday, June 29.  In order to qualify for the compensation assignment, at least one of the two assignments (either written or programming) must have been submitted, declared admissible, and graded at least a 4.0.</LI>
</DD>

<DT>May 29</DT><DD>
<LI>The programming assignment and accompanying code templates will be expected to appear around Saturday on blackboard as a zip.  Next week, June 1 to  June 5, is scheduled for orientation on the programming assignment, that is, to study the assignment, to study the code templates, to get the code templates running, and to ask questions to Yolan on blackboard. Yolan is the one who wrote an astounding assignment and fabricated tight templates &#129305; .</LI>
<LI>The week after next week, lectures will continue.  They will then have a more applied character, since the lectures are no longer examinated, and if I want you to keep viewing these lectures, if at all, they necessarily must be focused strongly on the programming assignment.</LI>
<LI>Lectures are planned on the following topics, not necessarily in the following order: <A href="http://www.cs.uu.nl/docs/vakken/ias/main.php?page=opdracht_netlogo_2_strategieen" target="_blank">a similar but simpler programming assignment</A>  that I wrote within the framework of the bachelor course Inl. Adaptieve Systemen (click <A href="http://translate.google.com/translate?hl=en&sl=nl&tl=en&u=http://www.cs.uu.nl/docs/vakken/ias/main.php?page=opdracht_netlogo_2_strategieen" target="_blank">here</A> for an English version), <A href="page_replicator_dynamic.php" target="main">the replicator dynamic</A>, <A href="page_satisficing.php" target="main">satisficing play</A>, and <A href="page_teach_and_follow.php" target="main">Bully</A>.  The <I>grand table</I> concept will be discussed in the context of a presentation on <A href="page_tournament.php" target="main">comparing MAL algorithms empirically</A>.  The programming and these topics will give, I think, an interesting second term.</LI>
</DD>



<DT>May 21</DT><DD>
<LI>Screencast and slides on Bayesian play published.</LI>
<LI><A href="netlogo-web.php" target="main">Netlogo 6 web examples</A> on Bayesian and the &beta;-distribution (used with Bayesian updating of a  &beta;-distribution on slide 49 [page 328 in the PDF]) published and verified.  Again notice that the web demos's run in a Javascript implementation of Netlogo.  They are are likely to break if anything is asked beyond the ordinary.   If you are interest in running them, I would recommend to just download the source and open it in Netlogo 6 itself.</LI>
</DD>

<DT>May 16</DT><DD>
<LI>Screencast and slides on gradient dynamics and WoLF published.</LI>
<LI>Netlogo 6 web examples on gradient dynamics published and verified.</LI>
<LI>Netlogo 6 web examples on fictitious play repaired, except &ldquo;Q-learning, replicator dynamic, fictitious play in a two-person matrix game&rdquo;.  (This one was harder to convert.)</LI>
</DD>

<DT>May 13</DT><DD>
<LI>Screencast and slides on fictitious play, Part 1 and 2 published.</LI>
<LI>Netlogo 6 web examples on fictitious play published.</LI>
</DD>

<DT>May 12</DT><DD>
<LI>In <A href="assisgnment_2020_theoretical.php" target="main">written assignment</A>, weights to assessment criteria were modified so as to better reflect their importance.  Anticipating on questions as to why the assignment page is modified after pubication, I believe there is enough time to mentally process minor such modifications weeks from the deadline.  My conviction is that weighing credit carefully is all for the better, because your hard work deserves to receive credit where credit is due.  Major modifications, such as question coverage, will no longer be carried out.  Promise &#129491;&#x1f91e;.</LI>
</DD>

<DT>May 11</DT><DD>
<LI>Screencast and slides on no-regret learning, Part 1 and 2 published.</LI>
<LI>In written assignment, weights to assessment criteria added.</LI>
</DD>

<DT>May 07</DT><DD>
<LI>Screencast and slides on different types of equilibria published.</LI>
<LI>List of topics in written assignment finalised.</LI>
</DD>

<DT>May 04</DT><DD>
<LI>Screencast and slides on reinforcement learning published.</LI>
<LI>Written assignment published.</LI>
</DD>

<DT>April 29</DT><DD>
<LI>Screencast and slides on multi-armed bandit algorithms published.</LI>
<LI>Schedule updated to 2020.  The schedule page contains links to topic pages with slides, articles and book chapters.</LI>
<LI>UCB demo added to <A href="netlogo.php" target="main">Netlogo demo collection.</A>.</LI>
</DD>

<DT>April 27</DT><DD>
<LI>A mail was sent with a username and password to get access to course material on the site where you are now.  Notice that some material cannot be found elsewhere on the internet.</LI>
<LI>The same mail contains a link to screencasts.</LI>
<LI>Bug Hunt demo added to <A href="netlogo.php" target="main">Netlogo demo collection.</A></LI>
</DD>

<DT>April 23</DT><DD>
<LI>Greetings and welcome.  In 2020 MAL is organised as follows.</LI>
<LI>Lectures are replaced by screencasts of about 15-30 minutes each, which will be published regularly as from Tue, 28 Apr 2020 09:00 (24 hour notation).
It is recommended to check this site on a daily basis.</LI>
<LI>The written tests are replaced by a written assignment mid-term and a programming assignment end-term, both to be handed in through <A href="https://uu.blackboard.com/webapps/blackboard/execute/announcement?method=search&course_id=_128763_1" target="_blank">blackboard</A>.
<LI>The written assignment will be published on this site at Tue, 26 May 2020 12:00, due Fri, 29 May 2020 23.59.  Support will be offered through blackboard during the time the assignment is out.</LI>
<LI>The programming assignment will be published 29 May 23:59, due 26 Jun 2020 23:59.  You will be asked to program a selection of MAL algorithms (in Python).  Further you will be asked to compare these algorithms through a so-called <I>grand table</I>, the replicator dynamic, and through Nash-equilibria of the grand table (with <A href="http://www.gambit-project.org/" target="_blank">Gambit</A>).  For those that have taken <A href="http://www.cs.uu.nl/docs/vakken/ias/" target="_blank">Inl. Adaptieve Systemen</A>: the programming assignment is like <A href="http://www.cs.uu.nl/docs/vakken/ias/main.php?page=opdracht_netlogo_2_strategieen" target="_blank">strategie&euml;n vergelijken</A>, but then with reactive algoritms (tit-for-tat, Pavlov, etc.) replaced by learning algorithms (ficitious play, no-regret learning, etc.) and with one benchmark game (prisoner's dilemma) replaced by a suite of benchmark games (for example: 3x3 games with integer payoffs in [0,3]).  Your software is accompanied by a so-called <I>study document</I> (which is NOT the documentation of the software) in which results are reported, analysed and discussed.  Support will be offered through blackboard throughout the assignment.</LI>
</DD>

<!--
<DT>July 11</DT><DD>
   <LI>Answers to retake exam published.  See &ldquo;Old exams&rdquo;. Grades retake published and entered in Osiris.</LI>
   <LI>Happy holidays!</LI>
</DD>

<DT>July 02</DT><DD>
   <LI>Grades end-term exam published.</LI>
   <LI>We (course evalation committee, students, myself) would appreciate it if you would take the time to fill out the Caracal evaluation, also if you have something nice to say.  Many thanks.</LI>
</DD>

<DT>June 27</DT><DD>
   <LI>Answers to end-term exam published.  See &ldquo;Old exams&rdquo;. The plan is to publish grades in the course of next Tuesday.</LI>
</DD>

<DT>June 22</DT><DD>
   <LI>In slides on Gradient Dynamics, &ldquo;Like in fictitious play, players project each other on a mixed strategy.&rdquo; replaced by &ldquo;Like in fictitious play, opponents are modelled through a mixed strategy.&rdquo;.</LI>
   <LI>As announced in the last lecture, the deadline for submitting student items is June 23, midnight.</LI>
</DD>


<DT>June 11</DT><DD>
   <LI>Suggested homework for next Tuesday: practice with all items on Bayesian play and hypothesis testing in previous exams.  Try to formulate a multiple choice item yourself  (cf. news item June 04).</LI>
   <LI>Joss-10% in demo corrected, and visualization in slides of it.</LI>
   <LI>Subject of June 13 is learning by hypothesis testing.  Best preparation is to study Ch. 8 of &ldquo;Strategic Learning and its Limits&rdquo; (2004).</LI>
</DD>

<DT>June 07</DT><DD>
   <LI>Suggested homework for next Tuesday:  give an explanation as to why the third graph in Fig.&nbsp;4 of &ldquo;Satisficing and Learning Cooperation in the Prisoner's Dilemma&rdquo; is asymmetric.  Practice an item on satisficing play in one of the old exams.  Try to think of a new item on satisficing play (cf. news item June 04).</LI>
</DD>

<DT>June 04</DT><DD>
   <LI>Invitation to contribute to the end-term exam.  (See &ldquo;Student items&rdquo; in the left margin.)</LI>
</DD>

<DT>May 31</DT><DD>
   <LI>Grades mid-term published.</LI>
</DD>

<DT>May 24</DT><DD>
   <LI>In response to questions, elaborated on answers mid-term multi-{2,3,6,8,11,12}.</LI>
   <LI>Tuesday, May 28 no lectures due to <A href="https://dutchreview.com/dutch-news/everything-you-need-to-know-about-the-public-transport-strike-in-the-netherlands-on-may-28/" target="_blank">regional public transport strike</A>.</LI>
</DD>

<DT>May 23</DT><DD>
   <LI>Answers to mid-term exam published.  See &ldquo;Old exams&rdquo;.</LI>
   <LI>Decreased the threshold to qualify for the retake from four to two.  See <A href="http://www.cs.uu.nl/education/vak.php?vak=INFOMAA" target="_blank">departemental course page</A>. (Otherwise you'd have to score an eight or higher for the other exam in order to make it to the resit.  Now you'd have to score a four or higher for the other exam.)</LI>
</DD>

<DT>May 22</DT><DD>
   <LI>As promised in the first lecture, the mid-term exam will consist of two open questions and twelve multiple-choice questions.  Addtional scratch paper will be distributed 10-30 minutes after the start of the exam.  Good luck with the last preparations. Hope to see you tomorrow!</LI>
   <LI><A href="exams/MAL_exam_2018_19_1_xxx.pdf" target="_blank">A mockup of the 2018-19 mid-term</A> has been published .  This way you can inform yourself about the format of the exam.</LI>
</DD>

<DT>May 16</DT><DD>
   <LI>Reworked answer of Item 2 in mid-term exam 2017-18 (difference between APM and CPM in reinforcement learning).  Hope this helps.   (If you retrieved this document earlier, then please make sure you download the latest version indeed by emptying the cache of your browser.  There is a time stamp at the very end of the document.)</LI>
</DD>

<DT>May 14</DT><DD>
   <LI>Most if not all <A href="netlogo.php" target="main">Netlogo&nbsp;demos</A> <A href="stuff/Demos_Netlogo_v6.0.4.zip" target="_blank">translated to v6.0.4 and zipped</A> by Yolan van der Horst. &ldquo;De snelheid van sommige simulaties op normal speed is trager dan in de oude versie, deze kunnen simpelweg sneller door de slider te verplaatsen.  De frames per seconds voor het maken van opnames zijn vastgezet op 25 fps.&rdquo;</LI>
   <LI>To lessen the burden on the end term exam, the lectures on evolutionary game theory and satisficing play are swapped.  (EGT is heavier and SP is lighter.)</LI>
</DD>

<DT>May 09</DT><DD>
   <LI>Homework for next Tuesday: the old mid-term exams contain items on reinforcement learning and regret matching.  You may consider practicing them.</LI>
</DD>

<DT>May 07</DT><DD>
   <LI>Inequality on Slide 25 of the slides on reinforcement learning refactored.</LI>
</DD>

<DT>May 03</DT><DD>
   <LI>Excercise on p. 12 of slides &ldquo;repeated games&rdquo; disambiguated.  Example on bottom of p. 13 improved (at the expense of layout ..).  Computation of <I>&delta;>1/2</I> on slide 17 completely rewritten.</LI>
   <LI>Practicing one item of a previous exam would be a minimalistic approach.  In addition to the homework for next Tuesday, it doesn't hurt to play with a few exercises at the end of Peter's chapter on repeated games.</LI>
</DD>

<DT>May 01</DT><DD>
   <LI>Homework for next Tuesday: Item 1 of the 2016-2017 mid-term exam on Nash equilibria in repeated games.</LI>
   <LI>Here is a <A href="http://www.cs.uu.nl/docs/vakken/maa/papers/" target="_blank">link to a dynamically generated list of publications</A>.  (Use provided username/passwd combination.)</LI>
   <LI>Numbered slides (on request).</LI>
   <LI>Listed Netlogo demo's (on request).  See left margin.</LI>
</DD>

<DT>April 25, 2019</DT><DD>
   <LI>Homework for next Tuesday: study Sec.&nbsp;7.1 of Chapt.&nbsp;7 of &ldquo;Multi-agent Systems&rdquo; of Shoham and Leyton-Brown, and make a summary for yourself.  See the &ldquo;Introduction&rdquo;-page in the time table.  Knowledge of Sec.&nbsp;7.1 is essential to be able to participate in next Tuesday's lecture.</LI>
</DD>

<DT>April 22, 2019</DT><DD>
   <LI>Welcome.  You are supposed to check this page every day.</LI>
</DD>
<!--
Februari 05, 2018
<UL>
   <LI><A href="grades.php" target="main">Grades</A> are in.  For retake regulations, see <A href="http://www.cs.uu.nl/education/vak.php?vak=INFOMAA" target="_blank">departemental course page</A>.</LI>
   <LI>Thanks for taking this course.  All the best in the rest of your studies!</LI>
</UL>

January 27, 2018
<UL>
   <LI><A href="stuff/slides_part2.zip" target="_blank">Slides</A> of last six lectures, without incremental buildup.  Layout may be disrupted (mostly due to ruptured line spacing).  If that is the case cf. the original slides.</LI>
</UL>


November 11, 2017
<UL>
   <LI>Greetings and welcome.</LI>
   <LI>The first week of MAL is used to get on a par with the essentials of game theory. You are free to skip the first lectures if you are well-versed in game theory.  On the other hand, I am pretty sure that even if you <I>are</I> comfortable with game theory, it is always beneficial to brush up your knowledge and to tune in with the notation.  You may even learn something new here and there.</LI>
   <LI>This course is examined by means of a mid term exam, a final exam, and two programming assignments.</LI>
   <LI>Consult the <A href="http://www.cs.uu.nl/education/vak.php?vak=INFOMAA" target="_blank">departemental&nbsp;course&nbsp;page</A> for rooms, locations and exam dates.</LI>
   <LI>Consult the <A href="programming.php" target="main">programming&nbsp;assignments&nbsp;page</A> for latest submisssion dates (a.k.a. &ldquo;deadlines&rdquo;).</LI>
<!--
   <LI>Read organisation page. You are expected to hand in five summaries and two programming assignments.  You can choose the dates on which you submit the summaries on the proviso that summaries must be handed in on the date of topic presentation.  No more than one summary per day.</LI>
   <LI>Read page with important dates.</LI>
   <LI>All documents to <CODE style="color: red">maa.cs</CODE><CODE>z</CODE><CODE style="color: red">.uu</CODE><CODE>z</CODE><CODE style="color: red">.nl@gmail.com</CODE> (remove the z's).</LI>
</UL>
-->


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Tue, 08 Jun 2021 11:16:25 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/news.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
