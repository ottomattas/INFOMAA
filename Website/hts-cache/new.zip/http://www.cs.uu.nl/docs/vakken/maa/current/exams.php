<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/exams.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Exams</H1>

<P>
<TABLE border="1" cellpadding="3" cellspacing="2">
   <TR valign="top">
      <TD align="right">prior<B>-16</B></TD>
      <TD colspan="3">seminar</TD>
   </TR>
   <TR valign="top">
      <TD align="right"><B>2016-17</B></TD>
      <TD><A href="exams/MAL_exam_2016_17_1.pdf" target="_blank">mid term</A></TD>
      <TD><A href="exams/MAL_exam_2016_17_2.pdf" target="_blank">end term</A></TD>
      <TD></TD>
   </TR>
   <TR valign="top">
      <TD align="right"><B>2017-18</B></TD>
      <TD><A href="exams/MAL_exam_2017_18_1.pdf" target="_blank">mid term</A></TD>
      <TD><A href="exams/MAL_exam_2017_18_2.pdf" target="_blank">end term</A></TD>
      <TD><A href="exams/MAL_exam_2017_18_3.pdf" target="_blank">retake  </A></TD>
   </TR>
   <TR valign="top">
      <TD align="right"><B>2018-19</B></TD>
      <TD><A href="exams/MAL_exam_2018_19_1.pdf" target="_blank">mid term</A></TD>
      <TD><A href="exams/MAL_exam_2018_19_2.pdf" target="_blank">end term</A></TD>
      <TD><A href="exams/MAL_exam_2018_19_3.pdf" target="_blank">retake  </A></TD>
   </TR>
   <TR valign="top">
      <TD align="right"><B>2019-20</B></TD>
      <TD colspan="3">Homework assignments, due to Covid-19</TD>
   </TR>
   <TR valign="top">
      <TD align="right"><B>2020-21</B></TD>
      <TD><A href="exams/MAL_exam_2020_21_1.pdf" target="_blank">mid term</A></TD>
      <TD>end term</TD>
      <TD>retake </TD>
   </TR>
</TABLE>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Thu, 27 May 2021 14:48:00 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/exams.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>

