<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_repeated_games.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Repeated games</H1>

<P><!-- description -->
Much interaction in multi-agent systems can be modelled through games (as in: &ldquo;game theory&rdquo;).  Much <I>learning</I> in multi-agent systems can therefore be modelled through learning in games.  Learning in games usually takes place through the (gradual) adaption of strategies (hence, behaviour) in a repeated game.  A repeated game is a stage game that is repeated an finite or a possibly infinite number of times.  Familiarity with the basic concepts and results from the theory of repeated games is essential to understand the mechanisms of multi-agent learning.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_RepeatedGames.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;May  3, 2019.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Repeated Games&rdquo; <I>Peters</I> (2008). Ch 7 of Game theory A Multi-Levelled Approach [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=repeated+games+peters+2008+ch+7+of+game+theory+a+multi+levelled+approach" target="_blank">scholar</A>, <A href="lib.php?query=repeated+games+peters+2008+ch+7+of+game+theory+a+multi+levelled+approach" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Speltheorie voor Economen&rdquo; <I>H. Peters</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=speltheorie+voor+economen+h+peters+2007" target="_blank">scholar</A>, <A href="lib.php?query=speltheorie+voor+economen+h+peters+2007" target="_blank">lib</A>]</LI>
<LI>&ldquo;Game Theory&rdquo; <I>Fudenberg and Tirole</I> (1991). Sec. 4.2 [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=game+theory+fudenberg+and+tirole+1991+sec+4+2" target="_blank">scholar</A>, <A href="lib.php?query=game+theory+fudenberg+and+tirole+1991+sec+4+2" target="_blank">lib</A>].  On the one-stage deviation principle.</LI>
<LI>&ldquo;Repeated Games, Trigger Strategies, and Tacit Collusion&rdquo; <I>Gintis</I> (2007). Ch. 6 from Game Theory Evolving [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=repeated+games+trigger+strategies+and+tacit+collusion+gintis+2007+ch+6+from+game+theory+evolving" target="_blank">scholar</A>, <A href="lib.php?query=repeated+games+trigger+strategies+and+tacit+collusion+gintis+2007+ch+6+from+game+theory+evolving" target="_blank">lib</A>]</LI>
<LI>Multiagent systems: algorithmic, game-theoretic, and logical foundations, Shoham and Leyton Brown, 2009 [<A href="http://www.masfoundations.org/download.html" target="_blank">book</A>].  Section on repeated games and Folk Theorems.</LI>
</OL>
</P>

<H2>Demos</H2>
<P>
<OL type="i">
<LI>You are invited to <A href="netlogo_repeated_game.php" target="_blank">play a repeated prisoner's dilemma against the computer</A>.</LI>
</OL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Sat, 07 Feb 2015 11:59:59 +01001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_repeated_games.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
