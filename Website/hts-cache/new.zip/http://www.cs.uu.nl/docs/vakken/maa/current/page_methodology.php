<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_methodology.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Methodology of MAL research</H1>

<P><!-- description -->
It is important to be clear on the objectives of research in multi-agent learning.  By this, it is meant that is important to indicate which problem we wish to address and it is important to indicate how we judge whether a certain learning algorithm is successful or not.  The thing with MAL is that there are various concurring but equally legitimate approaches.  These approaches can broadly be subdivided in descriptive (how do people [agents] learn?) and prescriptive (how should agents [people] learn?) theories.  MAL research draws from descriptive research in (among others) mathematical economics but is prescriptive by nature itself.  Prescriptive theories can be evaluated in various ways, for example by looking at past payoff, by demanding convergence in self-play, by requiring a best response in certain circumstances, or by other criteria.  The publications below address these issues.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P><!-- <P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
<H2>Slides</H2> T.B.P.      </TD>
      <TD align="right">
<H2>Assignment</H2> T.B.P.      </TD>
   </TR>
</TABLE>
</P>-->

<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;If Multiagent Learning is the Answer, What is the Question&rdquo; <I>Shoham et al.</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=if+multiagent+learning+is+the+answer+what+is+the+question+shoham+et+al+2007" target="_blank">scholar</A>, <A href="lib.php?query=if+multiagent+learning+is+the+answer+what+is+the+question+shoham+et+al+2007" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Multiagent Learning is not the Answer.  It is the Question&rdquo; <I>Stone</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=multiagent+learning+is+not+the+answer+it+is+the+question+stone+2007" target="_blank">scholar</A>, <A href="lib.php?query=multiagent+learning+is+not+the+answer+it+is+the+question+stone+2007" target="_blank">lib</A>]</LI>
<LI>&ldquo;Agendas for multi-agent learning&rdquo; <I>Gordon</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=agendas+for+multi+agent+learning+gordon+2007" target="_blank">scholar</A>, <A href="lib.php?query=agendas+for+multi+agent+learning+gordon+2007" target="_blank">lib</A>]</LI>
<LI>&ldquo;The possible and the impossible in multi-agent learning&rdquo; <I>H.P. Young</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+possible+and+the+impossible+in+multi+agent+learning+h+p+young+2007" target="_blank">scholar</A>, <A href="lib.php?query=the+possible+and+the+impossible+in+multi+agent+learning+h+p+young+2007" target="_blank">lib</A>]</LI>
<LI>&ldquo;Perspectives on multiagent learning&rdquo; <I>Sandholm</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=perspectives+on+multiagent+learning+sandholm+2007" target="_blank">scholar</A>, <A href="lib.php?query=perspectives+on+multiagent+learning+sandholm+2007" target="_blank">lib</A>]</LI>
</OL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 02 Apr 2014 16:58:19 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_methodology.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
