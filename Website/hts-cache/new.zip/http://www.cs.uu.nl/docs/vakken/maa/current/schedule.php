<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/schedule.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>
<H1>Time table</H1>

<TABLE border="0" cellpadding="4" cellspacing="0">

   <TR class="odd" valign="top">
      <TD align="right"><FONT class="day">Week&nbsp;17</FONT></TD>
      <TD width="0%"></TD><TD>Koningsdag</TD>
   </TR>
   <TR class="even" valign="top">
      <TD></TD>
      <TD>
01.</TD><TD><FONT class="topic_modest">Introduction</FONT>.<!-- (Lecturer)--> Several examples of multi-agent learning will be ... [<A href="page_introduction.php">more</A>]      </TD>
   </TR>

   <TR class="odd" valign="top">
      <TD align="right"><FONT class="day">Week&nbsp;18</FONT></TD>
      <TD>
02.</TD><TD><FONT class="topic_modest">Multi-armed bandit algorithms</FONT>.<!-- (Lecturer)--> A multi-armed bandit algorithm  ... [<A href="page_bandit_algorithms.php">more</A>]      </TD>
   </TR>
   <TR class="even" valign="top">
      <TD></TD>
      <TD>
03.</TD><TD><FONT class="topic_modest">Reinforcement learning</FONT>.<!-- (Lecturer)--> Reinforcement learning plays actions w ... [<A href="page_reinforcement_learning.php">more</A>]      </TD>
   </TR>

   <TR class="odd" valign="top">
      <TD align="right"><FONT class="day">Week&nbsp;19</FONT></TD>
      <TD>
04.</TD><TD><FONT class="topic_modest">Types of equilibria</FONT>.<!-- (Lecturer)--> Some multi-agent learning algorithms, suc ... [<A href="page_equilibria.php">more</A>]      </TD>
   </TR>
   <TR class="even" valign="top">
      <TD></TD>
      <TD></TD><TD>Ascension Day</TD>
   </TR>

   <TR class="odd" valign="top">
      <TD align="right"><FONT class="day">Week&nbsp;20</FONT></TD>
      <TD>
05.</TD><TD><FONT class="topic_modest">No-regret learning</FONT>.<!-- (Lecturer)--> No-regret learning is a natural extension  ... [<A href="page_no_regret.php">more</A>]      </TD>
   </TR>
   <TR class="even" valign="top">
      <TD></TD>
      <TD>
06.</TD><TD><FONT class="topic_modest">Fictitious play</FONT>.<!-- (Lecturer)--> Fictitious play works by sampling the actions ... [<A href="page_fictitious_play.php">more</A>]      </TD>
   </TR>

   <TR class="odd" valign="top">
      <TD align="right"><FONT class="day">Week&nbsp;21</FONT></TD>
      <TD></TD><TD>--</TD>
   </TR>
   <TR class="even" valign="top">
      <TD></TD>
      <TD></TD><TD>
Thursday May 27, 11.30-14.00, mid term exam in EDUC-&alpha;
      </TD>
   </TR>

   <TR class="odd" valign="top">
      <TD align="right"><FONT class="day">Week&nbsp;22</FONT></TD>
      <TD>
07.</TD><TD><FONT class="topic_modest">Gradient dynamics</FONT>.<!-- (Lecturer)--> Gradient dynamics refers to an approach whe ... [<A href="page_gradient_dynamics.php">more</A>]      </TD>
   </TR>
   <TR class="even" valign="top">
      <TD></TD>
      <TD>
08.</TD><TD><FONT class="topic_modest">Bayesian learning</FONT>.<!-- (Lecturer)--> Bayesian Learning, also known as rational l ... [<A href="page_bayesian_learning.php">more</A>]      </TD>
   </TR>

   <TR class="odd" valign="top">
      <TD align="right"><FONT class="day">Week&nbsp;23</FONT></TD>
      <TD>
09.</TD><TD><FONT class="topic_modest">A similar programming assignment in the bachelor</FONT>.<!-- (Lecturer)--> The programm ... [<A href="page_bachelor_assignment.php">more</A>]      </TD>
   </TR>
   <TR class="even" valign="top">
      <TD></TD>
      <TD></TD><TD>--</TD>
   </TR>

   <TR class="odd" valign="top">
      <TD align="right"><FONT class="day">Week&nbsp;24</FONT></TD>
      <TD>
10.</TD><TD><FONT class="topic_modest">The replicator dynamic</FONT>.<!-- (Lecturer)--> The replicator dynamic imagines how sp ... [<A href="page_replicator_dynamic.php">more</A>]      </TD>
   </TR>
   <TR class="even" valign="top">
      <TD></TD>
      <TD>
11.</TD><TD><FONT class="topic_modest">Satisficing play</FONT>.<!-- (Lecturer)--> Satisficing play is reinforcement learning w ... [<A href="page_satisficing.php">more</A>]      </TD>
   </TR>

   <TR class="odd" valign="top">
      <TD align="right"><FONT class="day">Week&nbsp;25</FONT></TD>
      <TD>
12.</TD><TD><FONT class="topic_modest">When to teach and when to follow</FONT>.<!-- (Lecturer)--> Agents in a MAL environment  ... [<A href="page_teach_and_follow.php">more</A>]      </TD>
   </TR>
   <TR class="even" valign="top">
      <TD></TD>
      <TD>
13.</TD><TD><FONT class="topic_modest">Comparing MAL algorithms empirically</FONT>.<!-- (Lecturer)--> Until 2005, say, MAL res ... [<A href="page_tournament.php">more</A>]      </TD>
   </TR>

   <TR class="odd" valign="top">
      <TD align="right"><FONT class="day">Week&nbsp;26</FONT></TD>
      <TD></TD><TD>
Tuesday June 29, 15.15-17.45, end term exam in EDUC-&gamma;
<!--
di 29 jun.	15:15 - 17:45	INFO - TT
Multi-agent learning - Eindresultaat
EDUC - GAMMA

do 1 jul.	11:30 - 14:30	INFO - TT
Multi-agent learning - Eindresultaat - extra tijdstudenten
EDUC - MEGARON
-->
   </TR>
   <TR class="even" valign="top">
      <TD></TD>
      <TD></TD><TD>
Friday July 2nd, 23.59 deadline programming assignment.  Submit at blackboard.
      </TD>
   </TR>

   <TR class="odd" valign="top">
      <TD align="right"><FONT class="day">Week&nbsp;27</FONT></TD>
      <TD></TD><TD>--</TD>
   </TR>
   <TR class="even" valign="top">
      <TD></TD>
      <TD></TD><TD>--</TD>
   </TR>

   <TR class="odd" valign="top">
      <TD align="right"><FONT class="day">Week&nbsp;28</FONT></TD>
      <TD></TD><TD>
Tuesday July 13th, 15:15-17:45, retake exam in EDUC-&gamma;
      </TD>
   </TR>
   <TR class="even" valign="top">
      <TD></TD>
      <TD></TD><TD>--</TD>
   </TR>

</TABLE>
</P>


<!--
<H2>Retake</H2>
<TABLE border="0" cellpadding="3" cellspacing="0" width="100%">

   <TR valign="top">
      <TD align="right" width="1%"><FONT class="day">Week&nbsp;26</FONT></TD>
      <TD width="99%">
Submission of <A href="assisgnment_2020_retake.php" target="main">retake</A>, on <A href="https://uu.blackboard.com/webapps/blackboard/execute/announcement?method=search&course_id=_128763_1" target="_blank">blackboard</A>, no later than July 17, 23:59.</BR>
      </TD>
   </TR>

</TABLE>
</P>
<P>
(*) Student presentation.
There is a <A href="slides_and_assignments.php" target="main">separate page with slides and assignments.</A>
</P>
-->


<A name="bottom"></A>

<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Tue, 27 Apr 2021 09:35:38 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/schedule.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
