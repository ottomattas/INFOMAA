<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_stochastic_games.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Stochastic games</H1>

<P><!-- description -->
A stochastic game (also: Markov game) is a generalisation of the concept of a repeated game.
A stochastic game is a combination of (multi-state) reinforcement learning (as in Sutton and Barto) and Von Neumann game theory.
With a stochastic game, the game in the next round (usually only the payoff matrix) depends on what happens in the current round.
Stochastic games are perfect tools to model and program multi-agent reinforcement learning, such as learning in games of incomplete information.  Card games, poker, backgammon, and simplified models of soccer are studied in this domain.
</P>
<P>
The theory of stochatic games is steep.  This presentation is based on simple examples and merely scratches the surface of a deep subject.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Multiagent Learning in the Presence of Agents with Limitations&rdquo; <I>Bowling</I> (2003). PhD thesis [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=multiagent+learning+in+the+presence+of+agents+with+limitations+bowling+2003+phd+thesis" target="_blank">scholar</A>, <A href="lib.php?query=multiagent+learning+in+the+presence+of+agents+with+limitations+bowling+2003+phd+thesis" target="_blank">lib</A>], Chapter 2.</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Decentralised reinforcement learning in Markov games&rdquo; <I>Vrancx</I> (2010). PhD thesis [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=decentralised+reinforcement+learning+in+markov+games+vrancx+2010+phd+thesis" target="_blank">scholar</A>, <A href="lib.php?query=decentralised+reinforcement+learning+in+markov+games+vrancx+2010+phd+thesis" target="_blank">lib</A>]</LI>
<LI>&ldquo;Markov games as a framework for multi-agent reinforcement learning&rdquo; <I>Littman</I> (1994) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=markov+games+as+a+framework+for+multi+agent+reinforcement+learning+littman+1994" target="_blank">scholar</A>, <A href="lib.php?query=markov+games+as+a+framework+for+multi+agent+reinforcement+learning+littman+1994" target="_blank">lib</A>]</LI>
<LI>&ldquo;Stochastic Games&rdquo; <I>Gimbert</I> (2001). Slides [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=stochastic+games+gimbert+2001+slides" target="_blank">scholar</A>, <A href="lib.php?query=stochastic+games+gimbert+2001+slides" target="_blank">lib</A>]</LI>
<LI>&ldquo;Stochastic games and dynamic programming&rdquo; <I>Henk Tijms</I> (2012) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=stochastic+games+and+dynamic+programming+henk+tijms+2012" target="_blank">scholar</A>, <A href="lib.php?query=stochastic+games+and+dynamic+programming+henk+tijms+2012" target="_blank">lib</A>]</LI>
</OL>
</P>




<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Tue, 07 Apr 2015 16:16:58 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_stochastic_games.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
