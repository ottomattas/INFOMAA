<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_teach_and_follow.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>When to teach and when to follow</H1>

<P><!-- description -->
Agents in a MAL environment must be able to decide when to teach and when to follow.  It is profitable to bully an agent that fares by fictitious play, but it is theoretically possible that this same agent plays a best response to your strategy only to trap you in the next 1000 rounds.  Deciding when to teach and when to follow is a difficult problem that is discussed and attacked by different researchers in various ways.
</P>
<P>
The paper on AWESOME (short version) was added by Shoshanna and Loy later on, to compensate overlap with the presentation on satisficing play last Thursday.  They give the following reading instructions: &ldquo;The two papers below introduce algorithms that decide when participants should teach
and when they should follow. Both algorithms use very different ways to
accomplish this. Of the AWESOME-2003 paper, section 2 and 4 can be skipped:
section 2 contains well known definitions, while section 4 contains a
detailed proof.&rdquo;
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_TeachAndFollow.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Jun 14, 2021.
      </TD>
      <TD>
<H2>Screencast</H2> <A href="https://www.youtube.com/playlist?list=PL8AyDiByAbIRqDa8G0_984VJYl2CzY-Zb" target="_blank">Youtube</A>
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P><!-- <P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
<H2>Slides</H2>
T.B.P.      </TD>
      <TD align="right">
<H2>Assignment</H2> T.B.P.      </TD>
   </TR>
</TABLE>
</P>
-->

<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Learning to Teach and Follow in Repeated Games&rdquo; <I>Crandall &amp; Goodrich</I> (2005) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+to+teach+and+follow+in+repeated+games+crandall+goodrich+2005" target="_blank">scholar</A>, <A href="lib.php?query=learning+to+teach+and+follow+in+repeated+games+crandall+goodrich+2005" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<UL>
<LI>&ldquo;AWESOME A general multiagent learning algorithm&rdquo; <I>Sandholm &amp; Konitzer</I> (2003) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=awesome+a+general+multiagent+learning+algorithm+sandholm+konitzer+2003" target="_blank">scholar</A>, <A href="lib.php?query=awesome+a+general+multiagent+learning+algorithm+sandholm+konitzer+2003" target="_blank">lib</A>]</LI>
<LI>&ldquo;AWESOME A general multiagent learning algorithm&rdquo; <I>Sandholm &amp; Konitzer</I> (2006) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=awesome+a+general+multiagent+learning+algorithm+sandholm+konitzer+2006" target="_blank">scholar</A>, <A href="lib.php?query=awesome+a+general+multiagent+learning+algorithm+sandholm+konitzer+2006" target="_blank">lib</A>] (Extended version.)</LI>
</UL>
</P>
<P>
Two papers, much like (<I>Crandall &amp; Goodrich</I>, 2005) but simpler:
<OL>
<LI>&ldquo;Satisficing and Learning Cooperation in the Prisoner's Dilemma&rdquo; <I>Stimpson et al.</I> (2001) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=satisficing+and+learning+cooperation+in+the+prisoner%27s+dilemma+stimpson+et+al+2001" target="_blank">scholar</A>, <A href="lib.php?query=satisficing+and+learning+cooperation+in+the+prisoner's+dilemma+stimpson+et+al+2001" target="_blank">lib</A>]</LI>
<LI>&ldquo;Learning To Cooperate in a Social Dilemma A Satisficing Approach to Bargaining&rdquo; <I>Stimpson et al.</I> (2003) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+to+cooperate+in+a+social+dilemma+a+satisficing+approach+to+bargaining+stimpson+et+al+2003" target="_blank">scholar</A>, <A href="lib.php?query=learning+to+cooperate+in+a+social+dilemma+a+satisficing+approach+to+bargaining+stimpson+et+al+2003" target="_blank">lib</A>]</LI>
</OL>
</P>
<P>
Other:
<OL>
<LI>&ldquo;Leading best-response strategies in repeated games&rdquo; <I>Littman &amp; Stone</I> (2001) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=leading+best+response+strategies+in+repeated+games+littman+stone+2001" target="_blank">scholar</A>, <A href="lib.php?query=leading+best+response+strategies+in+repeated+games+littman+stone+2001" target="_blank">lib</A>]</LI>
<LI>&ldquo;A Polynomial-time Nash Equilibrium Algorithm for Repeated Games&rdquo; <I>Littman &amp; Stone</I> (2005) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=a+polynomial+time+nash+equilibrium+algorithm+for+repeated+games+littman+stone+2005" target="_blank">scholar</A>, <A href="lib.php?query=a+polynomial+time+nash+equilibrium+algorithm+for+repeated+games+littman+stone+2005" target="_blank">lib</A>]</LI>
<LI>&ldquo;New Criteria and a New Algorithm for Learning in MASs&rdquo; <I>Powers &amp; Shoham</I> (2004) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=new+criteria+and+a+new+algorithm+for+learning+in+mass+powers+shoham+2004" target="_blank">scholar</A>, <A href="lib.php?query=new+criteria+and+a+new+algorithm+for+learning+in+mass+powers+shoham+2004" target="_blank">lib</A>]</LI>
<LI>&ldquo;Learning to Compete, Compromise, and Cooperate in Repeated General Sum Games&rdquo; <I>Crandall &amp; Goodrich</I> (2005) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+to+compete+compromise+and+cooperate+in+repeated+general+sum+games+crandall+goodrich+2005" target="_blank">scholar</A>, <A href="lib.php?query=learning+to+compete+compromise+and+cooperate+in+repeated+general+sum+games+crandall+goodrich+2005" target="_blank">lib</A>]</LI>
</OL>
</P>
<FONT color="#990099">Warning: 5 matches for '<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=crandall" target="_blank">crandall</A>', which is too many.</FONT>




<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 02 Apr 2014 16:58:19 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_teach_and_follow.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
