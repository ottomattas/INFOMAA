<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_introduction.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Introduction</H1>

<P><!-- description -->
Several examples of multi-agent learning will be played live and discussed, mostly to obtain an impression of the subtleties involved.
<A href="some_books.php" target="main">Covers of books</A> that I took with me during the first meeting in course year 2012-2013.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_Introduction.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Apr 28, 2021.
      </TD>
      <TD>
<H2>Screencast</H2> <A href="https://www.youtube.com/playlist?list=PL8AyDiByAbITCSVMo2FvHfg2ONXGzuzFp" target="_blank">Youtube</A>
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>

<H5>Key</H5>

<P>
<OL>
<LI>&ldquo;Strategic Learning and its Limits&rdquo; <I>Peyton Young</I> (2004). Ch. 1 [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=strategic+learning+and+its+limits+peyton+young+2004+ch+1" target="_blank">scholar</A>, <A href="lib.php?query=strategic+learning+and+its+limits+peyton+young+2004+ch+1" target="_blank">lib</A>]</LI>
<LI>&ldquo;Learning and Teaching&rdquo; <I>Shoham</I> (2009). Ch. 7 of Multi-agent Systems [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">scholar</A>, <A href="lib.php?query=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">lib</A>], Sec. 7.1.</LI>
</OL>
</P>


<H5>Support</H5>

<!--
<LI>&ldquo;Learning in Multi-agent systems&rdquo; <I>Vidal</I> (2009). Ch. 5 of Fundamentals of Multiagent Systems [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+in+multi+agent+systems+vidal+2009+ch+5+of+fundamentals+of+multiagent+systems" target="_blank">scholar</A>, <A href="lib.php?query=learning+in+multi+agent+systems+vidal+2009+ch+5+of+fundamentals+of+multiagent+systems" target="_blank">lib</A>]</LI>
<LI>&ldquo;An Overview of Cooperative and Competitive MAL&rdquo; <I>'t Hoen et al.</I> (2006) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=an+overview+of+cooperative+and+competitive+mal+%27t+hoen+et+al+2006" target="_blank">scholar</A>, <A href="lib.php?query=an+overview+of+cooperative+and+competitive+mal+'t+hoen+et+al+2006" target="_blank">lib</A>]</LI>
-->


<H4>Emergence of social conventions</H4>
<P>
<OL>
<LI>&ldquo;The Evolution of Conventions&rdquo; <I>Peyton Young</I> (1993) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+evolution+of+conventions+peyton+young+1993" target="_blank">scholar</A>, <A href="lib.php?query=the+evolution+of+conventions+peyton+young+1993" target="_blank">lib</A>]</LI>
<LI>&ldquo;On the Emergence of Social Conventions&rdquo; <I>Shoham &amp; Tennenholtz</I> (1997) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=on+the+emergence+of+social+conventions+shoham+tennenholtz+1997" target="_blank">scholar</A>, <A href="lib.php?query=on+the+emergence+of+social+conventions+shoham+tennenholtz+1997" target="_blank">lib</A>]</LI>
</OL>
</P>

<H4>Game theory</H4>
<P>
<OL>
<LI>
Y. Shoham and K. Leyton-Brown. <I>Essentials of Game Theory: A Concise, Multidisciplinary Introduction</I>. Morgan & Claypool Publishers, 2008 [<A href="http://books.google.nl/books?q=shoham+multi+agent+systems" target="_blank">book</A>].
(Almost entirely included in Shoham and Leyton-Brown's book on multi-agent systems that is freely downloadable through masfoundations.org.)
</LI>
<LI>
S.P. Hargreaves Heap & Y. Varoufakis (2004),
Game theory: a critical text, Routledge [<A href="http://books.google.nl/books?q=hargreaves+heap+varoufakis+game+theory+critical+text" target="_blank">book</A>].
</LI>
</OL>
</P>

<H4>Learning in games</H4>
<P>
The following two books are key publications in this area.
<OL>
<LI>
H. Peyton Young (2004): Strategic Learning and it Limits, Oxford UP. [<A href="http://books.google.nl/books?q=peyton+young+strategic+learning+limits" target="_blank">book</A>].
</LI>
<LI>
D. Fudenberg and D.K. Levine (1998), The Theory of Learning in Games, MIT Press. [<A href="http://books.google.nl/books?q=fudenberg+levine+theory+learning+games" target="_blank">book</A>].
</LI>
</OL>
</P>

<H4>Differential games</H4>
<P>
<OL>
<LI>
Isaacs (1975): Differential games: a mathematical theory with applications to Warfare and Pursuit, Control and Optimization [<A href="http://books.google.nl/books?q=isaacs+differential+games" target="_blank">book</A>]. Re-issued by Dover in 1999.
</LI>
<LI>Friedman (1971): Differential games [<A href="http://books.google.nl/books?q=friedman+differential+games" target="_blank">book</A>].  The last chapter, Ch. 8 is on n-person games.</LI>
<LI>H&aacute;jek (1975): Pursuit Games: An Introduction to the Theory and Applications of Differential Games of Pursuit and Evasion [<A href="http://books.google.nl/books?q=hajek+pursuit+games+dover" target="_blank">book</A>].  Resissued by Dover in 2008.</LI>
<LI>H. Stalford et al. (1973): &ldquo;Sufficiency conditions for Nash equilibria in N-person differential games&rdquo; in:
Topics in Differential Games, Elsevier [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=stalford+sufficiency+conditions+for+nash+equilibria+in+n+person+differential+games" target="_blank">scholar</A>].</LI>
<LI>D. Fudenberg et al. (1988): &ldquo;Open-Loop and Closed-Loop Equilibria in Dynamic Games with Many players,&ldquo;
in J. of Economic Theory <B>44</B>(1). pp. 1-18 [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=fudenberg+open+loop+and+closed+loop+equilibria+in+dynamic+games+with+many+players" target="_blank">scholar</A>].</LI>
</OL>
</P>

<H2>Demos</H2>
<P>
<OL type="i">
<LI><A href="netlogo_hunting_bugs.php" target="_blank">Hunting Bugs</A>.</LI>
<LI><A href="netlogo_gradient_dynamics.php" target="_blank">Gradient Dynamics</A>.</LI>
</OL>
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Mon, 28 Apr 2014 11:30:52 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_introduction.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>

<!--


<LI>
 [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=book" target="_blank">scholar</A>].
</LI>




-->
