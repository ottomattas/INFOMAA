<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_argumentation.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Argumentation-based MAL</H1>

<P><!-- description -->
Enrique Plaza is one of the few researchers who unites the areas of multi-agent learning, case-based reasoning and argumentation.
Machine argumentation, also known as <A href="http://en.wikipedia.org/wiki/Defeasible_reasoning" target="_blank">defeasible reasoning</A> [must click link to understand] and <A href="http://en.wikipedia.org/wiki/Machine_learning" target="_blank">machine learning</A> are rather disjoint fileds, because argumentation is symbolic while learning typically is numeric.  (New topic for 2013.)
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;An Argumentation based Approach to Multi-Agent Learning&rdquo; <I>Plaza</I> (2007) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=an+argumentation+based+approach+to+multi+agent+learning+plaza+2007" target="_blank">scholar</A>, <A href="lib.php?query=an+argumentation+based+approach+to+multi+agent+learning+plaza+2007" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Learning Information Exchange and Joint-Deliberation through Argumentation in Multi-agent Systems&rdquo; <I>Plaza et al.</I> (2008) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+information+exchange+and+joint+deliberation+through+argumentation+in+multi+agent+systems+plaza+et+al+2008" target="_blank">scholar</A>, <A href="lib.php?query=learning+information+exchange+and+joint+deliberation+through+argumentation+in+multi+agent+systems+plaza+et+al+2008" target="_blank">lib</A>]</LI>
<LI>&ldquo;Argumentation-Based Information Exchange&rdquo; <I>Plaza</I> (2009) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=argumentation+based+information+exchange+plaza+2009" target="_blank">scholar</A>, <A href="lib.php?query=argumentation+based+information+exchange+plaza+2009" target="_blank">lib</A>]</LI>
</OL>
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 02 Apr 2014 16:58:19 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_argumentation.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
