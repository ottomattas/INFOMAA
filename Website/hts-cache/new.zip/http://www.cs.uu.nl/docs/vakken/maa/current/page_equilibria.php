<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_equilibria.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Types of equilibria</H1>


<P><!-- description -->
Some multi-agent learning algorithms, such as
regret matching (RM, Hart &amp; Mas-Colell), converge, not to Nash equilibria, but to more general types of equilibria, such as so-called correlated equilibria and coarse correlated equilibria.  It is therefore worth the effort to study these new types of equilibria.
</P>
<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_Equilibria.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;May 25, 2021.
      </TD>
      <TD>
<H2>Screencast</H2> <A href="https://www.youtube.com/playlist?list=PL8AyDiByAbITxjCsYmspZAc266cMYgXsZ" target="_blank">Youtube</A>
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Strategic Learning and its Limits&rdquo; <I>Peyton Young</I> (2004). Ch. 3 [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=strategic+learning+and+its+limits+peyton+young+2004+ch+3" target="_blank">scholar</A>, <A href="lib.php?query=strategic+learning+and+its+limits+peyton+young+2004+ch+3" target="_blank">lib</A>], Ch. 3.</LI>
</UL>
</P>


<H5>Support</H5><!-- Support -->
<P>
<UL>
<LI>&ldquo;Strategically zero-sum games the class of games whose completely mixed equilibria cannot be improved upon&rdquo; <I>Moulin &amp; Vial</I> (1978) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=strategically+zero+sum+games+the+class+of+games+whose+completely+mixed+equilibria+cannot+be+improved+upon+moulin+vial+1978" target="_blank">scholar</A>, <A href="lib.php?query=strategically+zero+sum+games+the+class+of+games+whose+completely+mixed+equilibria+cannot+be+improved+upon+moulin+vial+1978" target="_blank">lib</A>]</LI>
<LI>&ldquo;Game Theory and Learning for Wireless Networks&rdquo; <I>Lasaulce &amp; Tembine</I> (2011) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=game+theory+and+learning+for+wireless+networks+lasaulce+tembine+2011" target="_blank">scholar</A>, <A href="lib.php?query=game+theory+and+learning+for+wireless+networks+lasaulce+tembine+2011" target="_blank">lib</A>]</LI>
<LI>&ldquo;Distributed Strategic Learning for Wireless Engineers&rdquo; <I>Tembine</I> (2012) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=distributed+strategic+learning+for+wireless+engineers+tembine+2012" target="_blank">scholar</A>, <A href="lib.php?query=distributed+strategic+learning+for+wireless+engineers+tembine+2012" target="_blank">lib</A>]</LI>
</UL>
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Thu, 05 Oct 2017 16:10:53 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_equilibria.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
