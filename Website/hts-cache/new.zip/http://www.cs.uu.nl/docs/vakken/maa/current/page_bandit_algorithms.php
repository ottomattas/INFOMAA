<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_bandit_algorithms.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Multi-armed bandit algorithms</H1>

<P><!-- description -->
A multi-armed bandit algorithm learns a game, just by observing the payoffs of its own actions.  It is not &ldquo;interest in&rdquo; the game matrix, opponent's behaviour and other game specific attributes. A MAB learner is also not interested in teaching (i.e., influencing) other players.  Important MAB algorithms are &epsilon;-Greedy learning, Q-learning, UCB learning, Thompson sampling, and Exp3.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_BanditAlgorithms.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;May  4, 2021.
      </TD>
      <TD>
<H2>Screencast</H2> <A href="https://www.youtube.com/playlist?list=PL8AyDiByAbIS4-fc0H5yM_6CKiNg7JQtZ" target="_blank">Youtube</A>
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Bandit problems (Book chapter)&rdquo; <I>Powell &amp; Ryzhov</I> (2012) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=bandit+problems+book+chapter+powell+ryzhov+2012" target="_blank">scholar</A>, <A href="lib.php?query=bandit+problems+book+chapter+powell+ryzhov+2012" target="_blank">lib</A>]</LI>
</UL>
</P>

<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Multi-armed Bandit Algorithms and Empirical Evaluation (article)&rdquo; <I>J. Vermorel &amp; M. Mohri</I> (2005) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=multi+armed+bandit+algorithms+and+empirical+evaluation+article+j+vermorel+m+mohri+2005" target="_blank">scholar</A>, <A href="lib.php?query=multi+armed+bandit+algorithms+and+empirical+evaluation+article+j+vermorel+m+mohri+2005" target="_blank">lib</A>].  Sec. 7.3</LI>
<LI>&ldquo;Algorithms for multi-armed bandit problems (article)&rdquo; <I>Volodymyr Kuleshov, Doina Precup</I> (2014) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=algorithms+for+multi+armed+bandit+problems+article+volodymyr+kuleshov+doina+precup+2014" target="_blank">scholar</A>, <A href="lib.php?query=algorithms+for+multi+armed+bandit+problems+article+volodymyr+kuleshov+doina+precup+2014" target="_blank">lib</A>]</LI>
<LI>&ldquo;The nonstochastic multiarmed bandit problem&rdquo; <I>P. Auer et al.</I> (2002) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+nonstochastic+multiarmed+bandit+problem+p+auer+et+al+2002" target="_blank">scholar</A>, <A href="lib.php?query=the+nonstochastic+multiarmed+bandit+problem+p+auer+et+al+2002" target="_blank">lib</A>]</LI>
<LI>&ldquo;Stochastic multi-armed-bandit problem with non-stationary rewards (article)&rdquo; <I>Besbes &amp; Gur</I> (2014) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=stochastic+multi+armed+bandit+problem+with+non+stationary+rewards+article+besbes+gur+2014" target="_blank">scholar</A>, <A href="lib.php?query=stochastic+multi+armed+bandit+problem+with+non+stationary+rewards+article+besbes+gur+2014" target="_blank">lib</A>]</LI>
</OL>
</P>

<H5>Demo</H5>
<P>
<UL>
<LI>
<A href="netlogo_ucb.php" target="_blank">UCB</A>.
</LI>
</UL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Thu, 30 Apr 2020 15:28:25 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_bandit_algorithms.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
