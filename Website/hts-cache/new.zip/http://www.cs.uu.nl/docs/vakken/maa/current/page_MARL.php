<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_MARL.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Multi-agent reinforcement learning</H1>

<P><!-- description -->
Reinforcement learning can be used, not only to evaluate one's own actions (independent learning, IL), but also to evaluate joint actions (joint action learning, JAL).  Put differently: reinforcement learning can also be put to use in (Von Neumann type of) games.  Q-learning is a well-known and simple to implement type of reinforcement learning.  It can empirically be shown that Q-JAL outperforms IL.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P><!-- <P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
<H2>Slides</H2>
T.B.P.      </TD>
      <TD align="right">
<H2>Assignment</H2> T.B.P.      </TD>
   </TR>
</TABLE>
</P>-->

<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;The Dynamics of Reinforcement Learning in Cooperative Multiagent Systems (AAAI conf. proc.)&rdquo; <I>Claus &amp; Boutilier</I> (1998) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+dynamics+of+reinforcement+learning+in+cooperative+multiagent+systems+aaai+conf+proc+claus+boutilier+1998" target="_blank">scholar</A>, <A href="lib.php?query=the+dynamics+of+reinforcement+learning+in+cooperative+multiagent+systems+aaai+conf+proc+claus+boutilier+1998" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;The Dynamics of Reinforcement Learning in Cooperative Multiagent Systems (AAAI WS-97-03)&rdquo; <I>Claus &amp; Boutilier</I> (1997) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+dynamics+of+reinforcement+learning+in+cooperative+multiagent+systems+aaai+ws+97+03+claus+boutilier+1997" target="_blank">scholar</A>, <A href="lib.php?query=the+dynamics+of+reinforcement+learning+in+cooperative+multiagent+systems+aaai+ws+97+03+claus+boutilier+1997" target="_blank">lib</A>]</LI>
<LI>&ldquo;Learning and Teaching&rdquo; <I>Shoham</I> (2009). Ch. 7 of Multi-agent Systems [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">scholar</A>, <A href="lib.php?query=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">lib</A>]</LI>
<LI>&ldquo;Markov games as a framework for multi-agent reinforcement learning&rdquo; <I>Littman</I> (1994) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=markov+games+as+a+framework+for+multi+agent+reinforcement+learning+littman+1994" target="_blank">scholar</A>, <A href="lib.php?query=markov+games+as+a+framework+for+multi+agent+reinforcement+learning+littman+1994" target="_blank">lib</A>]</LI>
<LI>&ldquo;The theory of learning in games&rdquo; <I>Fudenberg &amp; Levine</I> (1998). Ch. 4, Stochastic Fictitious Play and Mixed Strategy Equilibria [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+theory+of+learning+in+games+fudenberg+levine+1998+ch+4+stochastic+fictitious+play+and+mixed+strategy+equilibria" target="_blank">scholar</A>, <A href="lib.php?query=the+theory+of+learning+in+games+fudenberg+levine+1998+ch+4+stochastic+fictitious+play+and+mixed+strategy+equilibria" target="_blank">lib</A>]<LI>&ldquo;Multiagent Learning in the Presence of Agents with Limitations&rdquo; <I>Bowling</I> (2003). PhD thesis [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=multiagent+learning+in+the+presence+of+agents+with+limitations+bowling+2003+phd+thesis" target="_blank">scholar</A>, <A href="lib.php?query=multiagent+learning+in+the+presence+of+agents+with+limitations+bowling+2003+phd+thesis" target="_blank">lib</A>]</OL>
</P>

<H2>Demos</H2>
<P>
<OL type="i">
<LI><A href="netlogo_climbing_game.php" target="_blank">The climbing game</A>.</LI>
</OL>
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Mon, 30 Mar 2015 14:01:21 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_MARL.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
