<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_slime_mold.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Slime mold mechanisms</H1>

<P><!-- description -->
Slime mold is a broad term describing organisms that grow selectively based on the available food.  If there is no food, slime mould grows exploratively.  If there is food, the explorative branches die and the branches toward the food increase their capacity. The CS slime mold metaphor can be be used to handle intractable optimisation problems.  In CS there are two slime-mold metaphors, viz. <I>pipeline-based</I> (Japan school 1995-now) and <I>particle based</I> (UK school, 2005-now).  The particle-based approach is conceptually much simpler and gives results that are as rewarding the pipeline-based approach. Recently (2014), the particle-model has been used to tackle the travelling salesman problem, with some success.
</P>
<P>
CS models of slime mold are instances of so-called <I>massive multi-agent learning</I> or, more in particular, <I>stigmercy-based multi-agent learning</I>. Thousants of particles (agents) influence each other by dropping pheromone and perceiving pheromone on a grid.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5>
<P>
<UL>
<LI>&ldquo;Influences on the formation and evolution of Physarum Polycephalum inspired emergent transport networks&rdquo; <I>J. Jones</I> (2011) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=influences+on+the+formation+and+evolution+of+physarum+polycephalum+inspired+emergent+transport+networks+j+jones+2011" target="_blank">scholar</A>, <A href="lib.php?query=influences+on+the+formation+and+evolution+of+physarum+polycephalum+inspired+emergent+transport+networks+j+jones+2011" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
Physarum:
<OL>
<LI>&ldquo;Road planning with slime mould if Physarum built motorways&rdquo; <I>Adamatzky &amp; Jones</I> (2009) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=road+planning+with+slime+mould+if+physarum+built+motorways+adamatzky+jones+2009" target="_blank">scholar</A>, <A href="lib.php?query=road+planning+with+slime+mould+if+physarum+built+motorways+adamatzky+jones+2009" target="_blank">lib</A>]</LI>
<LI>&ldquo;Comparison of Bio-Inspired and Graph-Theoretic Algorithms for Design of Fault-Tolerant Networks&rdquo; <I>Becker</I> (2010) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=comparison+of+bio+inspired+and+graph+theoretic+algorithms+for+design+of+fault+tolerant+networks+becker+2010" target="_blank">scholar</A>, <A href="lib.php?query=comparison+of+bio+inspired+and+graph+theoretic+algorithms+for+design+of+fault+tolerant+networks+becker+2010" target="_blank">lib</A>]</LI>
<LI>&ldquo;Characteristics of pattern formation and evolution in approximations of Physarum transport networks&rdquo; <I>Jones</I> (2010) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=characteristics+of+pattern+formation+and+evolution+in+approximations+of+physarum+transport+networks+jones+2010" target="_blank">scholar</A>, <A href="lib.php?query=characteristics+of+pattern+formation+and+evolution+in+approximations+of+physarum+transport+networks+jones+2010" target="_blank">lib</A>]</LI>
<LI>&ldquo;Design of fault tolerant networks with agent-based simulation of Physarum Polycephalum&rdquo; <I>M. Becker</I> (2011) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=design+of+fault+tolerant+networks+with+agent+based+simulation+of+physarum+polycephalum+m+becker+2011" target="_blank">scholar</A>, <A href="lib.php?query=design+of+fault+tolerant+networks+with+agent+based+simulation+of+physarum+polycephalum+m+becker+2011" target="_blank">lib</A>]</LI>
<LI>&ldquo;Computation of the travelling salesman problem by a shrinking blob&rdquo; <I>Jones &amp; Adamatzky</I> (2014) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=computation+of+the+travelling+salesman+problem+by+a+shrinking+blob+jones+adamatzky+2014" target="_blank">scholar</A>, <A href="lib.php?query=computation+of+the+travelling+salesman+problem+by+a+shrinking+blob+jones+adamatzky+2014" target="_blank">lib</A>]</LI>
<LI>&ldquo;Permeability of terrain in particle-based models of Physarum Polycephalum&rdquo; <I>Van Dorsten</I> (2015). BSc Thesis [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=permeability+of+terrain+in+particle+based+models+of+physarum+polycephalum+van+dorsten+2015+bsc+thesis" target="_blank">scholar</A>, <A href="lib.php?query=permeability+of+terrain+in+particle+based+models+of+physarum+polycephalum+van+dorsten+2015+bsc+thesis" target="_blank">lib</A>]. <!--Accompanied by a <A href="https://github.com/sandervandorsten/Physarum-Polycephalum-Thesis" target="_blank">GitHub</A> archive.-->
<!--

************ Removed April-March 2018 ***************************************************************
*****************************************************************************************************

Three movies that accompany this thesis (click to see movie):

<P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         <A href="../Sander_MSc_Thesis_materiaal/recordings/the Netherlands 10 largest cities - filamentous condensation.avi" target="_blank"><IMG src="../Sander_MSc_Thesis_materiaal/recordings/the Netherlands 10 largest cities - filamentous condensation.png" width="100%" border="0"/></A>
      </TD>
      <TD>
         <A href="../Sander_MSc_Thesis_materiaal/recordings/Zeeland province capitals - filamentous condensation.avi" target="_blank"><IMG src="../Sander_MSc_Thesis_materiaal/recordings/Zeeland province capitals - filamentous condensation.png" width="100%" border="0"/></A>
      </TD>
      <TD>
         <A href="../Sander_MSc_Thesis_materiaal/recordings/Zeeland 10 largest cities - filamentous condensation.avi" target="_blank"><IMG src="../Sander_MSc_Thesis_materiaal/recordings/Zeeland 10 largest cities - filamentous condensation.png" width="100%" border="0"/></A>
      </TD>
   </TR>
</TABLE>
</P>-->

</LI>
<LI>Some <A href="https://www.google.nl/search?q=+physarum+polycephalum+site:nl" target="_blank">Dutch links</A>.</LI>
</OL>
</P>
<P>
Dicty:
<OL type="a">
<LI>&ldquo;A Simulation Study of Mechanisms of Group Selection of the Slime Mold Dictyostelium Discoideum&rdquo; <I>M. Becker</I> (2010) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=a+simulation+study+of+mechanisms+of+group+selection+of+the+slime+mold+dictyostelium+discoideum+m+becker+2010" target="_blank">scholar</A>, <A href="lib.php?query=a+simulation+study+of+mechanisms+of+group+selection+of+the+slime+mold+dictyostelium+discoideum+m+becker+2010" target="_blank">lib</A>]</LI>
<LI>&ldquo;A Simulation Model of Dictyostelium Discoideum for the Study of Evolutionary Selection Mechanisms&rdquo; <I>M. Becker</I> (2011) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=a+simulation+model+of+dictyostelium+discoideum+for+the+study+of+evolutionary+selection+mechanisms+m+becker+2011" target="_blank">scholar</A>, <A href="lib.php?query=a+simulation+model+of+dictyostelium+discoideum+for+the+study+of+evolutionary+selection+mechanisms+m+becker+2011" target="_blank">lib</A>]</LI>
<LI>&ldquo;A Simulation Model for the whole life cycle of the slime mold Dictyostelium Discoideum&rdquo; <I>M. Becker</I> (2013) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=a+simulation+model+for+the+whole+life+cycle+of+the+slime+mold+dictyostelium+discoideum+m+becker+2013" target="_blank">scholar</A>, <A href="lib.php?query=a+simulation+model+for+the+whole+life+cycle+of+the+slime+mold+dictyostelium+discoideum+m+becker+2013" target="_blank">lib</A>]</LI>
</OL>
</P>

<H2>Demos</H2>
<P>
Removed March-April 2018.
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Thu, 22 Mar 2018 22:09:40 +01001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_slime_mold.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
