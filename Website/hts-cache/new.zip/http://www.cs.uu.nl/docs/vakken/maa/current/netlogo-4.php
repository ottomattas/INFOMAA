<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/netlogo-4.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Netlogo 4 demos</H1>

<P>This is the prime source.  For a long time, these demos were runnable in the browser as Java applets.  This was a great way to present demos, as the applet's GUI was completely identical to Netlogo's GUI.  In the course of time, however, browsers became very restrictive with applets, which made them basically useless.  You can still invoke the applets if you dictate the browser to be very permissive with security on applets. Another way to get the Netlogo 4 demos running is to download Netlogo 4, download the demo of your interest, load the demo in Netlogo 4, and run it.  Sometimes the Netlogo programs need extra libraries (called <I>extensions</I> in Netlogo), and you'll have to download those extra libraries as well. In that case be sure to get the libraries made for NL4!  This collection was last updated Thu, 30 Apr 2020 00:50:11 +0200.</P>

<P><UL>
<LI><A href="netlogo_bayesian_learning.php" target="_blank">Bayesian learning</A> (June 11, 2019).</LI>
<LI><A href="netlogo_climbing_game.php" target="_blank">Climbing game</A> (April 24, 2014).</LI>
<LI><A href="netlogo_conditional_no_regret.php" target="_blank">Conditional no regret</A> (April 27, 2014).</LI>
<LI><A href="netlogo_cournot_dynamics.php" target="_blank">Cournot dynamics</A> (April  2, 2014).</LI>
<LI><A href="netlogo_emergence_of_cities.php" target="_blank">Emergence of cities</A> (April  2, 2014).</LI>
<LI><A href="netlogo_fictitious_play.php" target="_blank">Fictitious play</A> (April 19, 2014).</LI>
<LI><A href="netlogo_forecasting_and_calibration.php" target="_blank">Forecasting and calibration</A> (April  1, 2014).</LI>
<LI><A href="netlogo_gradient_dynamics.php" target="_blank">Gradient dynamics</A> (April  2, 2014).</LI>
<LI><A href="netlogo_hunting_bugs.php" target="_blank">Hunting bugs</A> (April  2, 2014).</LI>
<LI><A href="netlogo_hypothesis_testing.php" target="_blank">Hypothesis testing</A> (April  2, 2014).</LI>
<LI><A href="netlogo_learning_rate.php" target="_blank">Learning rate</A> (April  2, 2014).</LI>
<LI><A href="netlogo_multiarmed_bandit.php" target="_blank">Multiarmed bandit</A> (February  9, 2015).</LI>
<LI><A href="netlogo_no_regret.php" target="_blank">No regret</A> (March  8, 2015).</LI>
<LI><A href="netlogo_pd_nowak_may_spatial.php" target="_blank">Pd nowak may spatial</A> (February 24, 2017).</LI>
<LI><A href="netlogo_physarum.php" target="_blank">Physarum</A> (February 10, 2015).</LI>
<LI><A href="netlogo_repeated_game.php" target="_blank">Repeated game</A> (February  7, 2015).</LI>
<LI><A href="netlogo_replicator_dynamic.php" target="_blank">Replicator dynamic</A> (February 28, 2017).</LI>
<LI><A href="netlogo_replicator_dynamic_bifurcation.php" target="_blank">Replicator dynamic bifurcation</A> (May  1, 2017).</LI>
<LI><A href="netlogo_replicator_lyapunov.php" target="_blank">Replicator lyapunov</A> (April 12, 2017).</LI>
<LI><A href="netlogo_replicator_lyapunov_more.php" target="_blank">Replicator lyapunov more</A> (April 12, 2017).</LI>
<LI><A href="netlogo_satisficing_play.php" target="_blank">Satisficing play</A> (December 10, 2017).</LI>
<LI><A href="netlogo_shrinking_blob.php" target="_blank">Shrinking blob</A> (March 31, 2014).</LI>
<LI><A href="netlogo_slime_mold.php" target="_blank">Slime mold</A> (April 17, 2014).</LI>
<LI><A href="netlogo_slime_mold_micro.php" target="_blank">Slime mold micro</A> (April 17, 2014).</LI>
<LI><A href="netlogo_social_dynamics.php" target="_blank">Social dynamics</A> (April  2, 2014).</LI>
<LI><A href="netlogo_softmax.php" target="_blank">Softmax</A> (February 19, 2015).</LI>
<LI><A href="netlogo_spatial_continuous_actions.php" target="_blank">Spatial continuous actions</A> (April  2, 2014).</LI>
<LI><A href="netlogo_spatial_coordination.php" target="_blank">Spatial coordination</A> (April  2, 2014).</LI>
<LI><A href="netlogo_technology_adoption.php" target="_blank">Technology adoption</A> (April  2, 2014).</LI>
<LI><A href="netlogo_tournament_evolutionary.php" target="_blank">Tournament evolutionary</A> (March  9, 2015).</LI>
<LI><A href="netlogo_ucb.php" target="_blank">Ucb</A> (April 30, 2020).</LI>
</UL>
</P>

<!--
<P>For a long time, these demos were runnable as applets on the web.  Since Java became more restrictive with applets, however, you can run them only if you dictate the browser to be very permissive with security on applets.  Another way to get these demos running is to download Netlogo 4, download the demo of your interest, load the demo in Netlogo 4, and run it.</P>-->

<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Mon, 11 May 2020 15:33:08 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/netlogo-4.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
