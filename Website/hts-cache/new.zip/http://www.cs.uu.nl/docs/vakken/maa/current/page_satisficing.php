<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_satisficing.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Satisficing play</H1>

<P><!-- description -->
Satisficing play is reinforcement learning with the past average payoff as aspiration level (benchmark level).  Players switch to a random action as soon as their actual payoff drops below a certain threshold, else they remain stationary.  Satisficing play is an attractive model in situations where agents are unaware
of the structure of the game, such as the composition of the group of other players, the other players' actions, and the other players' payoffs.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_Satisficing.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Jun 14, 2021.
      </TD>
      <TD>
<H2>Screencast</H2> <A href="https://www.youtube.com/playlist?list=PL8AyDiByAbIQvjFKXqiCYQj7cZDrhZI1g" target="_blank">Youtube</A>
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P><!-- <P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
<H2>Slides</H2>
T.B.P.      </TD>
      <TD align="right">
<H2>Assignment</H2> T.B.P.      </TD>
   </TR>
</TABLE>
</P>-->

<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Satisficing and Learning Cooperation in the Prisoner's Dilemma&rdquo; <I>Stimpson et al.</I> (2001) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=satisficing+and+learning+cooperation+in+the+prisoner%27s+dilemma+stimpson+et+al+2001" target="_blank">scholar</A>, <A href="lib.php?query=satisficing+and+learning+cooperation+in+the+prisoner's+dilemma+stimpson+et+al+2001" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Evolving Aspirations and Cooperation&rdquo; <I>R. Karandikar et al.</I> (1998) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=evolving+aspirations+and+cooperation+r+karandikar+et+al+1998" target="_blank">scholar</A>, <A href="lib.php?query=evolving+aspirations+and+cooperation+r+karandikar+et+al+1998" target="_blank">lib</A>]</LI>
<LI>&ldquo;Learning To Cooperate in a Social Dilemma A Satisficing Approach to Bargaining&rdquo; <I>Stimpson et al.</I> (2003) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+to+cooperate+in+a+social+dilemma+a+satisficing+approach+to+bargaining+stimpson+et+al+2003" target="_blank">scholar</A>, <A href="lib.php?query=learning+to+cooperate+in+a+social+dilemma+a+satisficing+approach+to+bargaining+stimpson+et+al+2003" target="_blank">lib</A>]</LI>
<LI>&ldquo;Learning Successful Strategies in Repeated General-sum Games&rdquo; <I>Crandall</I> (2005) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+successful+strategies+in+repeated+general+sum+games+crandall+2005" target="_blank">scholar</A>, <A href="lib.php?query=learning+successful+strategies+in+repeated+general+sum+games+crandall+2005" target="_blank">lib</A>]</LI>
</OL>
</P>

<H5>Demos</H5>
<P>
<UL>
<LI>
<A href="netlogo_satisficing_play.php" target="_blank">Satisficing Play</A>.
</LI>
</UL>
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 05 Jun 2019 20:56:41 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_satisficing.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
