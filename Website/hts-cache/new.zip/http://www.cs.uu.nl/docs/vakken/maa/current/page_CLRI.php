<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_CLRI.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>The CLRI framework</H1>

<P><!-- description -->
CLRI (the letters correspond to the first letters of the parameters' names) is proposed as a framework to describe and predict the behaviour of learning agents in a multi-agent learning environment.
To this end, a difference equation is used. This equation relies on parameters which capture the agent�s learning abilities, such as its <B>C</B>hange
rate, <B>L</B>earning rate and <B>R</B>etention rate, as well as relevant aspects of the MAS such as the impact, or <B>I</B>nfluence, that
agents have on each other.  The research differs somewhat from other research in MAL, but is interesting because it tries to adopt a more abstract view.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;The CLRI Framework&rdquo; <I>Vidal &amp; Durfee</I> (2003) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+clri+framework+vidal+durfee+2003" target="_blank">scholar</A>, <A href="lib.php?query=the+clri+framework+vidal+durfee+2003" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Learning in Multi-agent systems&rdquo; <I>Vidal</I> (2009). Ch. 5 of Fundamentals of Multiagent Systems [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+in+multi+agent+systems+vidal+2009+ch+5+of+fundamentals+of+multiagent+systems" target="_blank">scholar</A>, <A href="lib.php?query=learning+in+multi+agent+systems+vidal+2009+ch+5+of+fundamentals+of+multiagent+systems" target="_blank">lib</A>]</LI>
</OL>
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 02 Apr 2014 16:58:19 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_CLRI.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
