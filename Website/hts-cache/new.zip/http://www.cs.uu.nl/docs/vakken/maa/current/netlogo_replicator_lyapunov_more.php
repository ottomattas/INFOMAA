<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/netlogo_replicator_lyapunov_more.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Demo</H1><!--
<P>
<applet code="org.nlogo.lite.Applet"
        archive="netlogo/NetLogoLite.jar"
        width="1520" height="666">
  <param name="DefaultModel"
         value="netlogo/ReplicatorLyapunov.nlogo">
</applet>
</P>
-->

<H2>Periodic and Lyapunov properties of a discrete replicator equation</H2>

<TABLE border="0" cellpadding="3" cellspacing="2" width="100%">
   <TR valign="top">
      <TD><IMG src="img/ReplicatorLyapunov/EvolLyapunov_endresult_15_15.png" width="100%" border="0"/></TD>
      <TD><IMG src="img/ReplicatorLyapunov/EvolLyapunov_periodic_15_15.png" width="100%" border="0"/></TD>
      <TD><IMG src="img/ReplicatorLyapunov/EvolLyapunov_lyapunov_15_15.png" width="100%" border="0"/></TD>
   </TR>
   <TR align="center">
      <TD><FONT style="font-size: 80%">End result [-7.5,22.5]&times[-8.5,21.5]</FONT></TD>
      <TD><FONT style="font-size: 80%">Periods [-7.5,22.5]&times[-8.5,21.5]</FONT></TD>
      <TD><FONT style="font-size: 80%">Lyapunov exponent [-7.5,22.5]&times[-8.5,21.5]</FONT></TD>
   </TR>
   <TR valign="top">
      <TD><IMG src="img/ReplicatorLyapunov/EvolLyapunov_endresult_04_04.png" width="100%" border="0"/></TD>
      <TD><IMG src="img/ReplicatorLyapunov/EvolLyapunov_periodic_04_04.png" width="100%" border="0"/></TD>
      <TD><IMG src="img/ReplicatorLyapunov/EvolLyapunov_lyapunov_04_04.png" width="100%" border="0"/></TD>
   </TR>
   <TR align="center">
      <TD><FONT style="font-size: 80%">End result [4.5,10.5]&times[3.5,9.5]</FONT></TD>
      <TD><FONT style="font-size: 80%">Periods [4.5,10.5]&times[3.5,9.5]</FONT></TD>
      <TD><FONT style="font-size: 80%">Lyapunov exponent [4.5,10.5]&times[3.5,9.5]</FONT></TD>
   </TR>
   <TR valign="top">
      <TD><IMG src="img/ReplicatorLyapunov/EvolLyapunov_endresult_01_01.png" width="100%" border="0"/></TD>
      <TD><IMG src="img/ReplicatorLyapunov/EvolLyapunov_periodic_01_01.png" width="100%" border="0"/></TD>
      <TD><IMG src="img/ReplicatorLyapunov/EvolLyapunov_lyapunov_01_01.png" width="100%" border="0"/></TD>
   </TR>
   <TR align="center">
      <TD><FONT style="font-size: 80%">End result [6.0,6.6]&times[7.5,8.1]</FONT></TD>
      <TD><FONT style="font-size: 80%">Periods [6.0,6.6]&times[7.5,8.1]</FONT></TD>
      <TD><FONT style="font-size: 80%">Lyapunov exponent [6.0,6.6]&times[7.5,8.1]</FONT></TD>
   </TR>
</TABLE>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 22 Mar 2017 12:58:13 +01001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/netlogo_replicator_lyapunov_more.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
