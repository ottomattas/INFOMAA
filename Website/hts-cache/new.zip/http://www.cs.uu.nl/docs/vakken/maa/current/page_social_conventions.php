<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_social_conventions.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Emergence of social conventions</H1>

<P><!-- description -->
It is studied how (typically large) agent populations that use different types of currency (Gold, Dollar, Euro, Pound, Francs) or standards (red, green, blue, yellow) may, through sampling, coordination or otherwise, converge to a single currency.  This problem can be described as a discrete Markov process.  This Markov process can be analysed qualitatively (by proving convergence) and (more difficult) quantitatively (by indicating the rate of convergence).
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_SocialConventions.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Jan 16, 2018.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P><!-- <P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
<H2>Slides</H2>
T.B.P.      </TD>
      <TD align="right">
<H2>Assignment</H2> No assignment*
      </TD>
   </TR>
</TABLE>
</P>
-->

<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Social Dynamics&rdquo; <I>Peyton Young</I> (2006) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=social+dynamics+peyton+young+2006" target="_blank">scholar</A>, <A href="lib.php?query=social+dynamics+peyton+young+2006" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;A First Course in Probability&rdquo; <I>5th Ed</I> (1998). Ross, Sec. 9.2 Markov Chains [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=a+first+course+in+probability+5th+ed+1998+ross+sec+9+2+markov+chains" target="_blank">scholar</A>, <A href="lib.php?query=a+first+course+in+probability+5th+ed+1998+ross+sec+9+2+markov+chains" target="_blank">lib</A>]</LI>
<LI>&ldquo;The Evolution of Conventions&rdquo; <I>Peyton Young</I> (1993) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+evolution+of+conventions+peyton+young+1993" target="_blank">scholar</A>, <A href="lib.php?query=the+evolution+of+conventions+peyton+young+1993" target="_blank">lib</A>]</LI>
<LI>&ldquo;Competition and Custom in Economic Contracts&rdquo; <I>Peyton Young et al.</I> (2001) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=competition+and+custom+in+economic+contracts+peyton+young+et+al+2001" target="_blank">scholar</A>, <A href="lib.php?query=competition+and+custom+in+economic+contracts+peyton+young+et+al+2001" target="_blank">lib</A>]</LI>
<LI>&ldquo;On the Emergence of Social Conventions&rdquo; <I>Shoham &amp; Tennenholtz</I> (1997) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=on+the+emergence+of+social+conventions+shoham+tennenholtz+1997" target="_blank">scholar</A>, <A href="lib.php?query=on+the+emergence+of+social+conventions+shoham+tennenholtz+1997" target="_blank">lib</A>]</LI>
<LI>&ldquo;Emergence of social conventions in complex networks&rdquo; <I>Delgado</I> (2002) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=emergence+of+social+conventions+in+complex+networks+delgado+2002" target="_blank">scholar</A>, <A href="lib.php?query=emergence+of+social+conventions+in+complex+networks+delgado+2002" target="_blank">lib</A>]</LI>
<LI>&ldquo;The role of clustering on the emergence of efficient social conventions&rdquo; <I>Pujol et al.</I> (2005) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+role+of+clustering+on+the+emergence+of+efficient+social+conventions+pujol+et+al+2005" target="_blank">scholar</A>, <A href="lib.php?query=the+role+of+clustering+on+the+emergence+of+efficient+social+conventions+pujol+et+al+2005" target="_blank">lib</A>]</LI>
<LI>&ldquo;Learning and Teaching&rdquo; <I>Shoham</I> (2009). Ch. 7 of Multi-agent Systems [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">scholar</A>, <A href="lib.php?query=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">lib</A>]</LI>
</OL>
</P>

<H5>Demos</H5>
<P>
<UL>
<LI>
<A href="netlogo_technology_adoption.php" target="_blank">Technology Adoption</A>.  Program by Uwe Th&uuml;mmel.
</LI>
<LI>
<A href="netlogo_social_dynamics.php" target="_blank">Social Dynamics</A>.
</LI>
<LI>
<A href="netlogo_spatial_coordination.php" target="_blank">Spatial coordination</A>.
</LI>
</UL>
</P>
<P>
*____________<BR/>
If you want to hand in an assignment, for example to improve your average, then complete the one of last year.  (Move mouse to upper-right corner of this page.)
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 02 Apr 2014 16:58:19 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_social_conventions.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
