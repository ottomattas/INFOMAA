<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_gradient_dynamics.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Gradient dynamics</H1>

<P><!-- description -->
Gradient dynamics refers to an approach where players are identified with mixed strategies. It it is assumed that players adapt their mixed strategies through hill-climbing in the payoff space. Every round, all players adapt their mixed strategy a little bit in the direction in which their gain in payoff is the highest.  For this to work, all players must know the mixed strategies of all other players.  In many games, hill-climbing converges to a Nash equilibrium.  In the remaining cases, convergence can be assured by putting extra conditions on the adaptation process, for example by learning fast in te presence of diminishing payoffs.  This is called WoLF (Win or Learn Fast).
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_GradientDynamics.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Jun  2, 2021.
      </TD>
      <TD>
<H2>Screencast</H2> <A href="https://www.youtube.com/playlist?list=PL8AyDiByAbITVU35Fx4WJZnL1T52W3pAo" target="_blank">Youtube</A>
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Convergence of Gradient Dynamics with a Variable Learning Rate&rdquo; <I>Bowling &amp; Veloso</I> (2001) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=convergence+of+gradient+dynamics+with+a+variable+learning+rate+bowling+veloso+2001" target="_blank">scholar</A>, <A href="lib.php?query=convergence+of+gradient+dynamics+with+a+variable+learning+rate+bowling+veloso+2001" target="_blank">lib</A>]
</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Nash Convergence of Gradient Dynamics in Games&rdquo; <I>Sing &amp; Kearns &amp; Mansour</I> (2000) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=nash+convergence+of+gradient+dynamics+in+games+sing+kearns+mansour+2000" target="_blank">scholar</A>, <A href="lib.php?query=nash+convergence+of+gradient+dynamics+in+games+sing+kearns+mansour+2000&nr=1" target="_blank">lib</A>]; &ldquo;Nash Convergence of Gradient Dynamics in Games&rdquo; <I>Sing &amp; Kearns &amp; Mansour</I> (2000) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=nash+convergence+of+gradient+dynamics+in+games+sing+kearns+mansour+2000" target="_blank">scholar</A>, <A href="lib.php?query=nash+convergence+of+gradient+dynamics+in+games+sing+kearns+mansour+2000&nr=2" target="_blank">lib</A>].  <FONT color="red">Warning: 2 matches for '<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=singh+kearns+mansour+dynamics+2000" target="_blank">singh kearns mansour dynamics 2000</A>'.</FONT></LI>
<LI>&ldquo;Multiagent learning using a variable learning rate&rdquo; <I>Bowling &amp; Veloso</I> (2002) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=multiagent+learning+using+a+variable+learning+rate+bowling+veloso+2002" target="_blank">scholar</A>, <A href="lib.php?query=multiagent+learning+using+a+variable+learning+rate+bowling+veloso+2002" target="_blank">lib</A>]</LI>
</OL>
</P>

<H5>Demo</H5>
<P>
<UL>
<LI>
<A href="netlogo_gradient_dynamics.php" target="_blank">Gradient Dynamics</A>.
</LI>
</UL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Sun, 07 Jan 2018 15:31:06 +01001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_gradient_dynamics.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
