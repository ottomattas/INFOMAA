<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/netlogo-web.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>


<H1>Netlogo 6 web demos</H1>

<P>
This page contains links to Netlogo 6 files that can be run directly through the <A href="https://www.google.com/search?q=netlogo+web+server" target="_blank">"netlogo-web" server</A>, a version of NetLogo that runs entirely in the browser.  The interface is not as  pretty as in Netlogo itself, and some of demos simply don't run because <A href="https://www.google.com/search?q=What+features+of+NetLogo+does+NetLogo+Web+lack+at+the+moment%3F" target="_blank">Netlogo's web version unfortunately doesn't understand all Netlogo primitives</A>, particular those that have to do with display and timing. Or the Netlogo program itself uses external libraries and then you're stuck as well. If you are still not discouraged then read on.  Netlogo's web version is slower than the Netlogo interpreter itself, because of the implementation and because in newer versions of Netlogo the frame rate is clamped at 30fps.  You can increase the frame rate by moving the upper slider to the right.  Still, programs in Netlogo's web version often run shower than in Netlogo itself. This collection was last updated Mon, 17 May 2021 11:07:07 +0200.
</P>

<P><UL>
<LI>
Bayesian play (May 21, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Bayesian play.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Bayesian play.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
Beta distribution (and an example of Bayesian updating with the Beta) (May 21, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Beta distribution (and an example of Bayesian updating with the Beta).nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Beta distribution (and an example of Bayesian updating with the Beta).nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
Comparison of reinforcement algorithms (May 17, 2021) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Comparison of reinforcement algorithms.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Comparison of reinforcement algorithms.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
ConditionalNoRegret (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/ConditionalNoRegret.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/ConditionalNoRegret.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
CournotDynamics (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/CournotDynamics.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/CournotDynamics.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
EmergenceOfCities (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/EmergenceOfCities.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/EmergenceOfCities.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
Fictitious Play on a 3x3 Matrix (May 16, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Fictitious Play on a 3x3 Matrix.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Fictitious Play on a 3x3 Matrix.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
Fictitious play on a game in normal form (May 16, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Fictitious play on a game in normal form.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Fictitious play on a game in normal form.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
ForecastingandCalibrationFosters (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/ForecastingandCalibrationFosters.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/ForecastingandCalibrationFosters.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
Gradient Learning in a Game (May 16, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Gradient Learning in a Game.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Gradient Learning in a Game.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
Gradient fictitious play (May 16, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Gradient fictitious play.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Gradient fictitious play.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
GradientDynamics (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/GradientDynamics.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/GradientDynamics.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
HuntingBugs (April 27, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/HuntingBugs.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/HuntingBugs.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
HypothesisTesting (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/HypothesisTesting.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/HypothesisTesting.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
LearningRate (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/LearningRate.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/LearningRate.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
MultiArmedBandit (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/MultiArmedBandit.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/MultiArmedBandit.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
NoRegretLearning (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/NoRegretLearning.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/NoRegretLearning.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
PD Axelrod Tournament - Evolutionary (w. Nash) (June  6, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/PD Axelrod Tournament - Evolutionary (w. Nash).nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/PD Axelrod Tournament - Evolutionary (w. Nash).nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
PDNowakMaySpatial (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/PDNowakMaySpatial.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/PDNowakMaySpatial.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
PhysarumPolycephalum (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/PhysarumPolycephalum.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/PhysarumPolycephalum.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
Prisoner's dilemma feasible payoffs (June  6, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Prisoner's dilemma feasible payoffs.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Prisoner's dilemma feasible payoffs.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
Q-learning, replicator dynamic, fictitious play in a two-person matrix game (May 13, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Q-learning, replicator dynamic, fictitious play in a two-person matrix game.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Q-learning, replicator dynamic, fictitious play in a two-person matrix game.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
RepeatedGameAgainstComputer (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/RepeatedGameAgainstComputer.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/RepeatedGameAgainstComputer.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
Replicator dynamic (evolutionary dynamics) - phase space (June  6, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Replicator dynamic (evolutionary dynamics) - phase space.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Replicator dynamic (evolutionary dynamics) - phase space.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
ReplicatorDynamic (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/ReplicatorDynamic.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/ReplicatorDynamic.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
ReplicatorDynamicBifurcation (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/ReplicatorDynamicBifurcation.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/ReplicatorDynamicBifurcation.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
Satisficing play (1) (June 16, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Satisficing play (1).nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Satisficing play (1).nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
Satisficing play (2) (June 16, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Satisficing play (2).nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Satisficing play (2).nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
Satisficing play (3) (June 16, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Satisficing play (3).nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Satisficing play (3).nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
Simplex tutor (2) (June  6, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Simplex tutor (2).nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/Simplex tutor (2).nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
SlimeBlob (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SlimeBlob.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SlimeBlob.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
SlimeMold (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SlimeMold.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SlimeMold.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
SlimeMoldMicro (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SlimeMoldMicro.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SlimeMoldMicro.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
SocialDynamics (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SocialDynamics.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SocialDynamics.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
SoftmaxQuantalResponse (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SoftmaxQuantalResponse.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SoftmaxQuantalResponse.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
SpatialContinuousActions (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SpatialContinuousActions.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SpatialContinuousActions.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
SpatialCoordination (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SpatialCoordination.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/SpatialCoordination.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
TheClimbingGame (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/TheClimbingGame.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/TheClimbingGame.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
TournamentEvolutionary (May  7, 2019) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/TournamentEvolutionary.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/TournamentEvolutionary.nlogo" target="_blank">right-click and save</A>.</LI>
<LI>
UCB1 (April 30, 2020) -- <A href="http://netlogo-web.org/web?http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/UCB1.nlogo" target="_blank">run in Netlogo-web</A> or <A href="http://www.cs.uu.nl/docs/vakken/maa/current/netlogo/6.0.1/UCB1.nlogo" target="_blank">right-click and save</A>.</LI>
</UL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 02 Jun 2021 09:58:58 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/netlogo-web.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
