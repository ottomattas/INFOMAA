<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_no_regret.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>No-regret learning</H1>

<P><!-- description -->
No-regret learning is a natural extension of reinforcement learning.  Both forms of learning are based on payoffs in past play.  The difference between reinforcement learning and no-regret learning is that reinforcement learning is based on realised play, while no-regret learning is based on hypothetical play (i.e., what could have been played).   A requirement for no-regret learning is that alternative payoffs are known, for example through complete knowledge of a stationary payoff matrix.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_NoRegret.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;May 19, 2021.
      </TD>
      <TD>
<H2>Screencast</H2> <A href="https://www.youtube.com/playlist?list=PL8AyDiByAbITkUEw0b6q8stmTmqHxlu5s" target="_blank">Youtube</A>
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Strategic Learning and its Limits&rdquo; <I>Peyton Young</I> (2004). Ch. 2 [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=strategic+learning+and+its+limits+peyton+young+2004+ch+2" target="_blank">scholar</A>, <A href="lib.php?query=strategic+learning+and+its+limits+peyton+young+2004+ch+2" target="_blank">lib</A>], Sec. 2.4 <A href="http://en.wiktionary.org/wiki/ff." target="_blank">ff</A>.</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Learning and Teaching&rdquo; <I>Shoham</I> (2009). Ch. 7 of Multi-agent Systems [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">scholar</A>, <A href="lib.php?query=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">lib</A>]</LI>
<LI>&ldquo;Regret in the On-Line Decision Problem&rdquo; <I>Foster et al.</I> (1999) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=regret+in+the+on+line+decision+problem+foster+et+al+1999" target="_blank">scholar</A>, <A href="lib.php?query=regret+in+the+on+line+decision+problem+foster+et+al+1999" target="_blank">lib</A>]</LI>
<LI>&ldquo;A Simple Adaptive Procedure Leading to Correlated Equilibrium&rdquo; <I>Hart et al.</I> (2000) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=a+simple+adaptive+procedure+leading+to+correlated+equilibrium+hart+et+al+2000" target="_blank">scholar</A>, <A href="lib.php?query=a+simple+adaptive+procedure+leading+to+correlated+equilibrium+hart+et+al+2000" target="_blank">lib</A>]</LI>
<LI>&ldquo;Convergence and No-Regret in MAL&rdquo; <I>M. Bowling</I> (2005) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=convergence+and+no+regret+in+mal+m+bowling+2005" target="_blank">scholar</A>, <A href="lib.php?query=convergence+and+no+regret+in+mal+m+bowling+2005" target="_blank">lib</A>]</LI>
<LI>Timothy Rothgarden's <A href="https://youtu.be/ssAEgJKRe9o" target="_blank">lecture</A> on no-regret.</LI>

</OL>
</P>

<H5>Demos</H5>
<P>
<UL>
<LI><A href="netlogo_no_regret.php" target="_blank">Netlogo demo</A> of no-regret learning.</LI>
</UL>
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 29 Nov 2017 21:53:06 +01001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_no_regret.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
