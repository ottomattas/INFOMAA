<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_calibration.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Prediction, postdiction, and calibration</H1>

<P><!-- description -->
Like fictitious play and Bayesian learning, calibration tries to predict the future based on past play.  A sequence of binary forecasts is calibrated if in all periods where the occurrence of 1 is predicted with p is actually confirmed by the empirical frequency distribution.   In 1997-1999 it was proven that for any desired degree of accuracy &epsilon; &gt; 0 there exist random forecasting rules that are &epsilon;-calibrated for all paths of play.  In this period is was also proven that if all players use a calibrated forecasting rule and play best responses, the empirical frequency of play converges to the set of correlated equilibria.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_Calibration.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Oct  6, 2017.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P><!--<P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
<H2>Slides</H2> T.B.P.      </TD>
      <TD align="right">
<H2>Assignment</H2> T.B.P.      </TD>
   </TR>
</TABLE>
</P>-->

<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Strategic Learning and its Limits&rdquo; <I>Peyton Young</I> (2004). Ch. 5 [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=strategic+learning+and+its+limits+peyton+young+2004+ch+5" target="_blank">scholar</A>, <A href="lib.php?query=strategic+learning+and+its+limits+peyton+young+2004+ch+5" target="_blank">lib</A>]</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<UL>
<LI>&ldquo;Self-Calibrating Priors Do Not Exist&rdquo; <I>Oakes</I> (1985) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=self+calibrating+priors+do+not+exist+oakes+1985" target="_blank">scholar</A>, <A href="lib.php?query=self+calibrating+priors+do+not+exist+oakes+1985" target="_blank">lib</A>]</LI>
</UL>
</P>

<H5>Demo</H5>
<P>
<UL>
<LI>
<A href="netlogo_forecasting_and_calibration.php" target="_blank">Forecasting and Calibration according to Foster</A>.
</LI>
</UL>
</P>



<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Tue, 22 Apr 2014 10:09:26 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_calibration.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
