<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_fictitious_play.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Fictitious play</H1>

<P><!-- description -->
Fictitious play works by sampling the actions of the opponent(s), and replying with a best response to the sampled mixed strategy.  Fictitious play is a pure follower strategy, in the sense that it completely adapts to the play of opponents.  Fictitious play is intuitive and possesses a number of interesting properties, such as correspondence to Nash equilibria under certain conditions.  On the other hand, fictitious play can also be trapped in cyclic play and is easily exploitable by teaching strategies.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_FictitiousPlay.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;May 19, 2021.
      </TD>
      <TD>
<H2>Screencast</H2> <A href="https://www.youtube.com/playlist?list=PL8AyDiByAbIQTCi2ad39aWsFDLPGrr62h" target="_blank">Youtube</A>
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Strategic Learning and its Limits&rdquo; <I>Peyton Young</I> (2004). Ch. 6 [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=strategic+learning+and+its+limits+peyton+young+2004+ch+6" target="_blank">scholar</A>, <A href="lib.php?query=strategic+learning+and+its+limits+peyton+young+2004+ch+6" target="_blank">lib</A>].</LI>
</UL>
</P>
<P>
<!--
<FONT class="alert">Warning: you are asked to summarise a section and a chapter.  This is difficult, because the texts are written at different levels and with different objectives.  Moreover, Ch. 6 of PY is relatively lengthy, which means that you have to practice a different summarisation technique.  Start early, and take your time.</FONT>-->
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Learning and Teaching&rdquo; <I>Shoham</I> (2009). Ch. 7 of Multi-agent Systems [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">scholar</A>, <A href="lib.php?query=learning+and+teaching+shoham+2009+ch+7+of+multi+agent+systems" target="_blank">lib</A>], Sec. 7.2.</LI>
<LI>&ldquo;The theory of learning in games&rdquo; <I>Fudenberg &amp; Levine</I> (1998). Ch. 2, Fictitious play [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+theory+of+learning+in+games+fudenberg+levine+1998+ch+2+fictitious+play" target="_blank">scholar</A>, <A href="lib.php?query=the+theory+of+learning+in+games+fudenberg+levine+1998+ch+2+fictitious+play&nr=1" target="_blank">lib</A>]; &ldquo;The theory of learning in games&rdquo; <I>Fudenberg &amp; Levine</I> (1998). Ch. 4, Stochastic Fictitious Play and Mixed Strategy Equilibria [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=the+theory+of+learning+in+games+fudenberg+levine+1998+ch+4+stochastic+fictitious+play+and+mixed+strategy+equilibria" target="_blank">scholar</A>, <A href="lib.php?query=the+theory+of+learning+in+games+fudenberg+levine+1998+ch+4+stochastic+fictitious+play+and+mixed+strategy+equilibria&nr=2" target="_blank">lib</A>].  <FONT color="red">Warning: 2 matches for '<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=fictitious+play+fudenberg+levine" target="_blank">fictitious play fudenberg levine</A>'.</FONT></LI>
<LI>&ldquo;Multiagent Learning in the Presence of Agents with Limitations&rdquo; <I>Bowling</I> (2003). PhD thesis [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=multiagent+learning+in+the+presence+of+agents+with+limitations+bowling+2003+phd+thesis" target="_blank">scholar</A>, <A href="lib.php?query=multiagent+learning+in+the+presence+of+agents+with+limitations+bowling+2003+phd+thesis" target="_blank">lib</A>].  Sec. 3.1.5  Fictitious Play.</LI>
<LI>&ldquo;Brown's original fictitious play&rdquo; <I>Berger</I> (2006) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=brown%27s+original+fictitious+play+berger+2006" target="_blank">scholar</A>, <A href="lib.php?query=brown's+original+fictitious+play+berger+2006" target="_blank">lib</A>]</LI>
<LI>&ldquo;On No-Regret Learning, Fictitious Play, and Nash Equilibrium&rdquo; <I>Greenwald et al.</I> (2001) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=on+no+regret+learning+fictitious+play+and+nash+equilibrium+greenwald+et+al+2001" target="_blank">scholar</A>, <A href="lib.php?query=on+no+regret+learning+fictitious+play+and+nash+equilibrium+greenwald+et+al+2001" target="_blank">lib</A>]</LI>
</OL>
</P>


<H2>Demos</H2>
<P>
<OL type="i">
<LI><A href="netlogo_softmax.php" target="_blank">Test softmax a.k.a. mixed logit a.k.a. quantal response</A>.</LI>
<LI><A href="netlogo_fictitious_play.php" target="_blank">Fictitious Play on a 3x3 matrix</A>.</LI>
</OL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Thu, 19 Feb 2015 11:00:07 +01001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_fictitious_play.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
