<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_bachelor_assignment.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>A similar programming assignment in the bachelor</H1>

<P><!-- description -->
The programming assignment &ldquo;Strategie&euml;n vergelijken&rdquo; (&ldquo;Comparing strategies&rdquo;) in the bachelor course &ldquo;Inleiding Adaptieve Systemen&rdquo; (&ldquo;Introducton to Adaptive Systems&rdquo;) is a natural pre-decessor of the end-term programming assignment of this course.  It is instructive to track down parallels and differences, and from there to have a first acquaintance with the replicator dynamic.</A>
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_BachelorAssignment.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Jun  6, 2020.
      </TD>
      <TD>
<H2>Screencast</H2> <A href="https://www.youtube.com/playlist?list=PL8AyDiByAbIRpwRqjajBSVV7ccV4XTgy_" target="_blank">Youtube</A>
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P><!-- <P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
<H2>Slides</H2> T.B.P.      </TD>
      <TD align="right">
<H2>Assignment</H2> T.B.P.      </TD>
   </TR>
</TABLE>
</P>-->

<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>Bachelor programming assignment <A href="http://www.cs.uu.nl/docs/vakken/ias/main.php?page=opdracht_netlogo_2_strategieen" target="_blank">Strategie&euml;n vergelijken</A> (<A href="http://translate.google.com/translate?hl=en&sl=nl&tl=en&u=http://www.cs.uu.nl/docs/vakken/ias/main.php?page=opdracht_netlogo_2_strategieen" target="_blank">English translation</A>).</LI>
<LI>Bachelor course <A href="http://www.cs.uu.nl/docs/vakken/ias/" target="_blank">Inleiding Adaptieve Systemen</A>. <FONT class="marked">Notice that all pages of this course contain a footer with a link to an English translation</FONT>.</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>
<OL>
<LI>&ldquo;Competition and Cooperation&rdquo; <I>Flake</I> (1998). Ch. 17 of The Computational Beauty of Nature [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=competition+and+cooperation+flake+1998+ch+17+of+the+computational+beauty+of+nature" target="_blank">scholar</A>, <A href="lib.php?query=competition+and+cooperation+flake+1998+ch+17+of+the+computational+beauty+of+nature" target="_blank">lib</A>]</LI>
<LI>Weibull, J. W. (1997). <I>Evolutionary game theory</I>. MIT press.</LI>
<LI>Hofbauer, J., & Sigmund, K. (1998). <I>Evolutionary games and population dynamics</I>. Cambridge university press.</LI>
</OL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Tue, 02 Jun 2020 14:09:29 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_bachelor_assignment.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
