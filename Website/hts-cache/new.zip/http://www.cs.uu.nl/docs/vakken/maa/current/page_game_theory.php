<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_game_theory.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Essentials of game theory</H1>

<P><!-- description -->
Game theory (as: &ldquo;Von-Neumann-Morgenstern economic game theory&rdquo;) is an important prerequisite of multi-agent learning.  This year [ed.: 2017-18], the multi-agent learning course is offered in Block 2 rather than in Block 4.  Because of that, the multi-agent learning course is scheduled prior to the multi-agent systems course (Block 3).  The latter discusses a great deal of game theory.  Therefore, the first week of MAL is used to get on a par with the essentials of game theory. You are free to skip the first lectures if you are well-versed in game theory.  On the other hand, I am pretty sure that even if you <I>are</I> comfortable with game theory, it is always beneficial to brush up your knowledge and to tune in with the notation.  You may even learn something new.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_GameTheory.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;May  1, 2019.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>

<H5>Key</H5>
<P>
<OL>
<!--
<LI>
Y. Shoham and K. Leyton-Brown. <I>Essentials of Game Theory: A Concise, Multidisciplinary Introduction</I>. Morgan & Claypool Publishers, 2008 [<A href="http://books.google.nl/books?q=shoham+multi+agent+systems" target="_blank">book</A>].

</LI>
-->
<LI>&ldquo;Essentials of Game Theory; A Concise, Multidisciplinary Introduction&rdquo; <I>Y. Shoham &amp; K. Leyton-Brown</I> (2008) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=essentials+of+game+theory+a+concise+multidisciplinary+introduction+y+shoham+k+leyton+brown+2008" target="_blank">scholar</A>, <A href="lib.php?query=essentials+of+game+theory+a+concise+multidisciplinary+introduction+y+shoham+k+leyton+brown+2008" target="_blank">lib</A>].
(Almost entirely included in Shoham and Leyton-Brown's book on multi-agent systems that is freely downloadable through  <A href="http://masfoundations.org/" target="_blank">masfoundations.org</A>.)</LI>
<LI><A href="http://www.youtube.com/user/gametheoryonline" target="_blank">Game theory online</A>.  A series of Youtube videos, presented by Y. Shoham, K. Leyton-Brown and M. Jackson.</LI>
</OL>
</P>

<H5>Support</H5>
<P>
<OL>
<LI>Slides from <A href="http://www.google.com/search?&q=%22game+theory%22+lecturer+%22ulle+endriss%22+%22teaching+assistant%22+timetable" target="_blank">Ulle Endriss' course on game theory</A>.</LI>
<LI>
S.P. Hargreaves Heap & Y. Varoufakis (2004),
Game theory: a critical text, Routledge [<A href="http://books.google.nl/books?q=hargreaves+heap+varoufakis+game+theory+critical+text" target="_blank">book</A>].<!--
&ldquo;Game Theory; A Critical Introduction&rdquo; <I>S.P. Hargreaves Heap &amp; Y. Varoufakis</I> 2004  [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=game+theory+a+critical+introduction+s+p+hargreaves+heap+y+varoufakis+2004" target="_blank">scholar</A>, <A href="lib.php?query=game+theory+a+critical+introduction+s+p+hargreaves+heap+y+varoufakis+2004" target="_blank">lib</A>].-->
</LI>
<LI>Definition and explanation of <A href="https://youtu.be/GQItrgQUcFc" target="_blank">common knowledge of rationality (CKR)</A> (YouTube).</LI>
</OL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Mon, 29 Apr 2019 15:59:45 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_game_theory.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>

<!--


<LI>
 [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=book" target="_blank">scholar</A>].
</LI>




-->
