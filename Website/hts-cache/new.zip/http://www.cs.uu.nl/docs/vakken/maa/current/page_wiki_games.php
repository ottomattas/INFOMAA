<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_wiki_games.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Joint process games: from ratings to wikis</H1>


<P><!-- description -->
In 2010 PhD student Michael Munie (now engineer at Google in Paris) and his supervisor Yoav Shoham (one of the leading researchers in AI) introduced a new game called a <I>joint process game</I>.  In a joint process game, the history of actions determines the state, and the state and agent properties determine the payoff.  Joint process games have applications as diverse as aggregate rating sites and wiki page updates. When each agent has a personal goal, the play converges under a simple myopic action rule.  Not only do this simple dynamics converges, but the actions selected also form a Nash equilibrium. The limit point is not (as one may expect) the mean or the median of the set of agent goals, but the median of the set of agent goals and a set of focal points. Munie's work provides the first theoretical model of wiki-type behavior and opens the door to a completely new type of multi-agent learning.
</P>
<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Joint Process Games; From Ratings to Wikis&rdquo; <I>Munie &amp; Shoham</I> (2010) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=joint+process+games+from+ratings+to+wikis+munie+shoham+2010" target="_blank">scholar</A>, <A href="lib.php?query=joint+process+games+from+ratings+to+wikis+munie+shoham+2010" target="_blank">lib</A>]</LI>
</UL>
</P>

<H5>Support</H5><!-- Support -->
<P>
<UL>
<LI>&ldquo;Voting and Historical Games (PhD thesis)&rdquo; <I>Michael Munie</I> (2010) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=voting+and+historical+games+phd+thesis+michael+munie+2010" target="_blank">scholar</A>, <A href="lib.php?query=voting+and+historical+games+phd+thesis+michael+munie+2010" target="_blank">lib</A>]</li>
<LI>&ldquo;Intelligence in Wikipedia&rdquo; <I>D.S. Weld et al.</I> (2008) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=intelligence+in+wikipedia+d+s+weld+et+al+2008" target="_blank">scholar</A>, <A href="lib.php?query=intelligence+in+wikipedia+d+s+weld+et+al+2008" target="_blank">lib</A>]</LI>
<LI>&ldquo;WikiWalk; random walks on Wikipedia for semantic relatedness&rdquo; <I>E. Yeh et al.</I> (2009) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=wikiwalk+random+walks+on+wikipedia+for+semantic+relatedness+e+yeh+et+al+2009" target="_blank">scholar</A>, <A href="lib.php?query=wikiwalk+random+walks+on+wikipedia+for+semantic+relatedness+e+yeh+et+al+2009" target="_blank">lib</A>]</LI>
</UL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 29 Mar 2017 18:57:40 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_wiki_games.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
