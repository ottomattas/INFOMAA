<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_spatial_evolution.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Evolutionary dynamics in spatial games</H1>

<P><!-- description -->
Symmetric strategic games in normal form behave differently when played in a spatial environment.  Principles of evolutionary dynamics then come into play.
There are different ways in which evolutionary dynamics may proceed on a plane.  The first is described by M. Nowak, the second is described by G. Flake in Ch. 17 of The Computational Beauty of Nature.  In Nowak and May's game, players possess a history (or: memory) of length one.  In this way, players can base their strategy only on the events of the previous round.  In more complication versions, as described by Flake and others, players possess a full history that goes back to the first round.  With complete histories, players may execute more complex strategies.
</P>
<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> T.B.P.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P>
<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Evolutionary games and spatial chaos&rdquo; <I>M.A. Nowak &amp; R.M. May</I> (1992) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=evolutionary+games+and+spatial+chaos+m+a+nowak+r+m+may+1992" target="_blank">scholar</A>, <A href="lib.php?query=evolutionary+games+and+spatial+chaos+m+a+nowak+r+m+may+1992" target="_blank">lib</A>]</LI>
<LI>Pp. 293-305 of &ldquo;Competition and Cooperation&rdquo; <I>Flake</I> (1998). Ch. 17 of The Computational Beauty of Nature [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=competition+and+cooperation+flake+1998+ch+17+of+the+computational+beauty+of+nature" target="_blank">scholar</A>, <A href="lib.php?query=competition+and+cooperation+flake+1998+ch+17+of+the+computational+beauty+of+nature" target="_blank">lib</A>]</LI>
</UL>
</P>


<H5>Support</H5><!-- Support -->
<P>
<LI><A href="http://www.google.com/search?q=%22The+Evolution+of+Cooperation%22+axelrod+1984" target="_blank">The Evolution of Cooperation</A>, Robert Axelrod, 1984.</LI>
<LI><A href="http://scholar.google.com/scholar?q=Tyler+Singer-Clark+%22Morality+Metrics+On+Iterated+Prisoner’s+Dilemma+Players%22 " target="_blank">Morality Metrics On Iterated Prisoner’s Dilemma Players</A>
Tyler Singer-Clark, 2014 (<A href="http://www.cs.uu.nl/docs/vakken/ias/stuff/Morality_Metrics_On_Iterated_Prisoners_Dilemma_Players.pdf" target="_blank">lokale kopie</A>).</LI>
<LI>Page 227 of <A href="http://books.google.nl/books?id=A_VoDQAAQBAJ&pg=PA227" target="_blank">The Iterated Prisoners' Dilemma: 20 Years on</A>, Graham Kendall, Xin Yao, Siang Yew Chong, 2007</LI>
</P>


<H5>Demos</H5>
<P>
<UL><LI><A href="netlogo_pd_nowak_may_spatial.php" target="_blank">Nowak and May's spatial version of the prisoner's dilemma</A>.</LI>
<LI>Page <A href="http://www.cs.uu.nl/docs/vakken/ias/main.php?page=opdracht_netlogo_3_SIPD" target="_blank">Opdracht 3: de evolutie van samenwerking</A> from the bachelor course &ldquo;Inleiding Adaptieve Systemen&rdquo;, Opleiding Kunstmatige Intelligentie 2016-2017.  (In Dutch.   Netlogo not given because it is a programming assignment in Period 4 of the course year 2016-2017.)</LI>
</UL>
</P>


<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Mon, 01 May 2017 21:47:07 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_spatial_evolution.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
