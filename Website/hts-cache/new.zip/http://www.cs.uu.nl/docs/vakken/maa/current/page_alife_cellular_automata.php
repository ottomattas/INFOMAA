<HTML>

<HEAD>
   <TITLE>&nbsp;Multi-agent learning</TITLE>
   <LINK href="maa.css" rel="stylesheet" type="text/css">
   <LINK rel="SHORTCUT ICON" href="maa.ico"/>
   <SCRIPT src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></SCRIPT>
   <SCRIPT src="js/jquery.jslatex.js"></SCRIPT>
</HEAD>

<BODY>

<TABLE class="header" border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
               </TD>
      <TD align="right">
   <A class="invisible" href="../2019-20/page_alife_cellular_automata.php" target="main">Edition 2019-20</A>         Edition 2020-21      </TD>
   </TR>
</TABLE>

<H1>Real-valued spatial games</H1>

<P><!-- description -->
A real-valued spatial game is a variant of a discrete-valued spatial game.  In discrete-valued spatial games, actors occupy fixed locations on a grid and play a repeated game (typically the prisoner's dilemma).  Actors adopt strategies of successful neighbours.  A cellular automata is thus formed.  In real-valued spatial games, actions are taken from a closed real interval.  Adaptation is continuous, for example through hill-climbing.
</P>

<P>
<TABLE border="0" cellpadding="0" cellspacing="3" width="100%">
   <TR valign="top">
      <TD width="50%">
<H2>Presented by</H2> Lecturer.
      </TD>
      <TD>
<H2>Slides</H2> <A href="slides/MAA_powerdot_AlifeCellularAutomata.pdf"><IMG border="0" SRC="icon-pdf.gif"></A>&nbsp;Apr  2, 2014.
      </TD>
      <TD>
<H2>Screencast</H2> Not available.
      </TD>
      <TD align="left">
<H2>Assignment</H2> Not this year.
      </TD>
   </TR>
</TABLE>
</P><!--<P>
<TABLE border="0" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
<H2>Slides</H2>
T.B.P.      </TD>
      <TD align="right">
<H2>Assignment</H2> T.B.P.      </TD>
   </TR>
</TABLE>
</P>-->

<H2>Literature</H2>
<H5>Key</H5><!-- Key -->
<P>
<UL>
<LI>&ldquo;Variable investment, the Continuous Prisoner's Dilemma, and the Origin of Cooperation&rdquo; <I>Killingback et al.</I> (1999) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=variable+investment+the+continuous+prisoner%27s+dilemma+and+the+origin+of+cooperation+killingback+et+al+1999" target="_blank">scholar</A>, <A href="lib.php?query=variable+investment+the+continuous+prisoner's+dilemma+and+the+origin+of+cooperation+killingback+et+al+1999" target="_blank">lib</A>]<BR/>Note: in Fig. 1 on p. 1724: <I>B<SUB>0</SUB>[1-exp(-B<SUB>1</SUB>,I)]</I> (first letter is the digit 1, last letter is a capital I) must be <I>B<SUB>0</SUB>[1-exp(-B<SUB>1</SUB>*I)]</I>.   The function <I>exp</I> has only one argument.</LI>
</UL>
</P>
<H5>Support</H5><!-- Support -->
<P>

<OL>
<LI>&ldquo;Effects of Neighbourhood Size and Connectivity on the Spatial Continuous Prisoner's Dilemma&rdquo; <I>Doebeli et al.</I> (2004) [<A href="http://scholar.google.nl.proxy.library.uu.nl/scholar?q=effects+of+neighbourhood+size+and+connectivity+on+the+spatial+continuous+prisoner%27s+dilemma+doebeli+et+al+2004" target="_blank">scholar</A>, <A href="lib.php?query=effects+of+neighbourhood+size+and+connectivity+on+the+spatial+continuous+prisoner's+dilemma+doebeli+et+al+2004" target="_blank">lib</A>]</LI>
<LI>
Cf. <A href="http://users.soe.ucsc.edu/~ptowbin/biblio.html" target="_blank">Peter Towbin's bibliography on Landscape Dynamics and
the Continuous Prisoner's Dilemma</A>.
(Local copy <A href="stuff/CPD_bibliography.html" target="_blank">here</A>.)
</LI>
</OL>
</P>

<H5>Demos</H5>
<P>
<OL type="i">
<LI><A href="netlogo_spatial_continuous_actions.php" target="_blank">Spatial Prisoner's Dilemma with Variable Investment</A>.</LI>
</OL>
</P>




<P>
<FORM>
<TABLE class="footer" cellpadding="0" cellspacing="0" width="100%">
   <TR valign="top">
      <TD>
         Page last modified at Wed, 02 Apr 2014 16:58:19 +02001      </TD>
            <TD align="right">
         <A href="mailto:&quot;Gerard Vreeswijk&quot; &lt;gv@cs.uu.nl&gt;?subject=/science/wwwprojects/cs-www/www/docs/vakken/maa/current/page_alife_cellular_automata.php">Comments welcome</A>
      </TD>
         </TR>
</TABLE>
</FORM>
</P>
</BODY>
</HTML>
